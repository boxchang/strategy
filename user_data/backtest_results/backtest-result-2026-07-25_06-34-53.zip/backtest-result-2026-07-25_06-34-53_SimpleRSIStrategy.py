import numpy as np
import pandas as pd
from pandas import DataFrame
from datetime import datetime
from typing import Optional
import talib.abstract as ta
import logging
from freqtrade.strategy import IStrategy, IntParameter, DecimalParameter

logger = logging.getLogger(__name__)

class SimpleRSIStrategy(IStrategy):
    INTERFACE_VERSION = 3
    timeframe = '1h'
    can_short = False
    
    # 參數化設定
    buy_rsi = IntParameter(5, 30, default=20, space="buy", optimize=True)
    
    # 調整目標參數：停利 30% (0.30)，停損 25% (-0.25)
    profit_target = DecimalParameter(0.10, 0.50, default=0.30, space="sell", optimize=True)
    stoploss_val = DecimalParameter(0.10, 0.40, default=0.25, space="sell", optimize=True)

    # 初始停損設定 (對應 25% 的停損)
    stoploss = -0.25

    def __init__(self, config: dict) -> None:
        super().__init__(config)
        # 初始化時確保 stoploss 使用設定值
        self.stoploss = -self.stoploss_val.value

    use_custom_stoploss = False
    startup_candle_count = 20
    
    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=6)
        bollinger = ta.BBANDS(dataframe, timeperiod=20, nbdevup=2.0, nbdevdn=2.0)
        dataframe['bb_lower'] = bollinger['lowerband']
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['enter_long'] = 0
        
        # 移除時間過濾，僅根據 RSI 判斷
        rsi_low = (dataframe['rsi'] < self.buy_rsi.value)
        
        dataframe.loc[rsi_low, 'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['exit_long'] = 0
        return dataframe

    def custom_exit(self, pair: str, trade: 'Trade', current_time: datetime, current_rate: float,
                    current_profit: float, **kwargs) -> Optional[str]:
        # 使用更新後的獲利目標 30%
        if current_profit >= self.profit_target.value:
            return 'profit_target'
        return None

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: Optional[str],
                 side: str, **kwargs) -> float:
        return 5.0