import numpy as np
import pandas as pd
from pandas import DataFrame
from datetime import datetime
from typing import Optional
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib
from freqtrade.strategy import IStrategy, IntParameter

class SimpleRSIStrategy(IStrategy):
    """
    RSI 雙向極速交易策略 - 修改版
    - Short 條件: RSI < 10 (移除時間與 EMA 過濾)
    - 止損: 10%
    - 移動獲利: 獲利 8% 啟動，回撤至 5% 平倉
    """
    INTERFACE_VERSION = 3
    timeframe = '15m'
    can_short = True
    
    # 止損 10%
    stoploss = -0.10

    # 移動獲利設定
    trailing_stop = True
    trailing_stop_positive = 0.05
    trailing_stop_positive_offset = 0.08
    trailing_only_offset_is_reached = True

    # 參數設定
    buy_rsi = IntParameter(5, 30, default=10, space="buy", optimize=True)

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 計算 RSI
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['enter_long'] = 0
        dataframe['enter_short'] = 0

        # Short 條件: RSI < 10 (無時間限制)
        short_cond = (
            (dataframe['rsi'] < self.buy_rsi.value)
        )
        dataframe.loc[short_cond, 'enter_short'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['exit_long'] = 0
        dataframe['exit_short'] = 0
        return dataframe

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: Optional[str],
                 side: str, **kwargs) -> float:
        return 10.0