import numpy as np
import pandas as pd
from pandas import DataFrame
from datetime import datetime
from typing import Optional
import talib.abstract as ta
import logging
from freqtrade.strategy import IStrategy, IntParameter, DecimalParameter
from freqtrade.persistence import Trade

logger = logging.getLogger(__name__)

class SimpleRSIStrategy(IStrategy):
    INTERFACE_VERSION = 3
    timeframe = '15m'
    can_short = False

    # 資金與加倉 (DCA) 控制：將最大加倉次數嚴格限制為 1 次，防止倉位膨脹導致大賠
    position_adjustment_enable = True
    max_entry_position_adjustment = 1

    # 【主導出場機制】提高獲利目標，修正盈虧比
    minimal_roi = {
        "0": 0.08,     # 瞬時獲利 8% 出場
        "30": 0.04,    # 30 分鐘獲利 4% 出場
        "120": 0.02,   # 2 小時獲利 2% 出場
        "240": 0.008   # 4 小時保本微利出場
    }

    # 參數化設定
    buy_rsi = IntParameter(5, 30, default=22, space="buy", optimize=True)
    exit_rsi = IntParameter(65, 90, default=75, space="sell", optimize=True)
    leverage_val = IntParameter(1, 3, default=2, space="entry", optimize=True)

    # 參數化 Trailing Stop
    trailing_stop = True
    trailing_stop_positive = DecimalParameter(0.01, 0.05, default=0.015, space="sell", optimize=True)
    trailing_stop_positive_offset = DecimalParameter(0.02, 0.10, default=0.03, space="sell", optimize=True)
    trailing_only_offset_is_reached = True

    # 嚴格控制虧損上限：停損縮小至 -5% (配合 2 倍槓桿為 -10%)，杜絕巨額單筆虧損
    stoploss = -0.05
    use_custom_stoploss = False
    startup_candle_count = 200

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # RSI 指標
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=6)
        
        # 趨勢濾網：EMA 200 (確保只在大趨勢向上或震盪時進場)
        dataframe['ema_200'] = ta.EMA(dataframe, timeperiod=200)
        
        # 趨勢強度指標 ADX：ADX < 25 代表震盪盤 (RSI 抄底策略只允許在震盪盤執行)
        dataframe['adx'] = ta.ADX(dataframe, timeperiod=14)

        # 暴跌過濾：計算過去 1 小時 (4 根 15m K線) 的跌幅
        dataframe['roc_1h'] = ta.ROC(dataframe, timeperiod=4)

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['enter_long'] = 0

        # 1. RSI 超賣
        rsi_low = (dataframe['rsi'] < self.buy_rsi.value)
        # 2. 大趨勢濾網：價格高於 EMA 200
        is_uptrend = (dataframe['close'] > dataframe['ema_200'])
        # 3. 防瀑布濾網：1小時內跌幅不大於 3%
        no_crash = (dataframe['roc_1h'] > -3.0)
        # 4. 關鍵防護：ADX < 25 (確保只在盤整區間進行逆勢抄底，強單邊下跌時嚴禁接刀)
        is_ranging = (dataframe['adx'] < 25)

        dataframe.loc[
            rsi_low & is_uptrend & no_crash & is_ranging,
            'enter_long'
        ] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['exit_long'] = 0
        return dataframe

    def custom_exit(self, pair: str, trade: Trade, current_time: datetime, current_rate: float,
                    current_profit: float, **kwargs) -> Optional[str]:
        
        # 1. DCA 解套機制 (加倉過後，浮盈達 0.5% 即刻離場)
        if trade.nr_of_successful_entries > 1 and current_profit >= 0.005:
            return "dca_break_even_exit"

        # 2. RSI 獲利平倉 (獲利 > 1.0% 時才允許觸發 RSI 賣出)
        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        if not dataframe.empty:
            last_candle = dataframe.iloc[-1]
            if last_candle['rsi'] > self.exit_rsi.value and current_profit > 0.01:
                return "rsi_profit_exit"

        # 3. 時間停損：持倉超過 4 小時 (240 分鐘) 且處於虧損 (-1.5% 以下) 果斷認賠離場
        trade_duration = (current_time - trade.open_date_utc).total_seconds() / 60
        if trade_duration > 240 and current_profit < -0.015:
            return "time_stop_loss"

        return None

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: Optional[str],
                 side: str, **kwargs) -> float:
        return float(self.leverage_val.value)

    def adjust_trade_position(self, trade: Trade, current_time: datetime, current_rate: float,
                              current_profit: float, min_stake: float | None,
                              max_stake: float, **kwargs):
        # 最多只允許加倉 1 次
        if trade.nr_of_successful_entries >= self.max_entry_position_adjustment:
            return None

        # 檢查冷卻時間 (至少間隔 5 分鐘)
        if trade.date_last_filled_utc:
            seconds = (current_time - trade.date_last_filled_utc).total_seconds()
            if seconds < 300:
                return None

        dataframe, _ = self.dp.get_analyzed_dataframe(trade.pair, self.timeframe)
        if dataframe.empty:
            return None
        last_rsi = dataframe.iloc[-1]['rsi']

        base_stake = self.config.get('stake_amount', 30)
        if isinstance(base_stake, str) or base_stake is None:
            base_stake = 30

        min_s = min_stake if min_stake is not None else 0.0

        # 只有在虧損達到 -3.5% 且 RSI 再次低於 22 時，才允許加倉原本金額的 50%
        if current_profit <= -0.035 and last_rsi < 22 and trade.nr_of_successful_entries == 1:
            return max(min_s, min(base_stake * 0.5, max_stake)), "dca_stage1"

        return None