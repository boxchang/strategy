import numpy as np
import pandas as pd
from pandas import DataFrame
from datetime import datetime
from typing import Optional
import talib.abstract as ta
from freqtrade.strategy import IStrategy, IntParameter

class SimpleRSIStrategy(IStrategy):
    INTERFACE_VERSION = 3
    timeframe = '15m'
    can_short = True
    stoploss = -0.10
    
    tradable_balance_ratio = 0.99
    trailing_stop = True
    trailing_stop_positive = 0.05
    trailing_stop_positive_offset = 0.08
    trailing_only_offset_is_reached = True

    buy_rsi = IntParameter(5, 30, default=10, space="buy", optimize=True)

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 計算 RSI
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        
        # 修正：直接使用 tz_convert，因為 dataframe['date'] 已經是 UTC 時區
        try:
            vn_time = dataframe['date'].dt.tz_convert('Asia/Ho_Chi_Minh')
            print(f"DEBUG: 前三筆 K 線時間 (越南時間): {vn_time.head(3).tolist()}")
        except Exception as e:
            # 如果時間未標記時區，則補上 tz_localize
            vn_time = dataframe['date'].dt.tz_localize('UTC').dt.tz_convert('Asia/Ho_Chi_Minh')
            print(f"DEBUG: 前三筆 K 線時間 (轉換後): {vn_time.head(3).tolist()}")
        
        dataframe['debug_rsi'] = dataframe['rsi']
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['enter_long'] = 0
        dataframe['enter_short'] = 0

        # Short 條件: RSI < 10
        short_cond = (dataframe['rsi'].notna()) & (dataframe['rsi'] < self.buy_rsi.value)
        
        dataframe.loc[short_cond, 'enter_short'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['exit_long'] = 0
        dataframe['exit_short'] = 0
        return dataframe

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: Optional[str],
                 side: str, **kwargs) -> float:
        return 10.0