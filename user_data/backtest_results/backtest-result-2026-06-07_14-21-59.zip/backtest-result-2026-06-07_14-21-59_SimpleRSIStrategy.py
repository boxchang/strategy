import numpy as np
import pandas as pd
from pandas import DataFrame
from datetime import datetime, time
from typing import Optional
import talib.abstract as ta
import logging
from freqtrade.strategy import IStrategy, IntParameter

logger = logging.getLogger(__name__)

class SimpleRSIStrategy(IStrategy):
    INTERFACE_VERSION = 3
    timeframe = '15m'
    can_short = False # 根據獲利分析，Long 策略表現較穩，改為僅做多
    stoploss = -0.05  # 優化停損，減少虧損擴大
    
    startup_candle_count = 200 # 需預讀 200 根 K 線以計算 EMA(200)
    
    tradable_balance_ratio = 0.99
    trailing_stop = True
    trailing_stop_positive = 0.05
    trailing_stop_positive_offset = 0.08
    trailing_only_offset_is_reached = True

    buy_rsi = IntParameter(5, 50, default=20, space="buy", optimize=True)

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # RSI 與 EMA200 趨勢指標
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=6)
        dataframe['ema200'] = ta.EMA(dataframe, timeperiod=200)
        
        # 標記 RSI 的前一根數值，用於偵測反轉訊號
        dataframe['rsi_prev'] = dataframe['rsi'].shift(1)
        
        return dataframe

    def is_us_market_open(self, current_time: datetime) -> bool:
        # 美股開盤 (09:30 ET) = 14:30 UTC / 收盤 (16:00 ET) = 21:00 UTC
        time_utc = current_time.time()
        return time(14, 30) <= time_utc < time(21, 0)

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['enter_long'] = 0
        dataframe['enter_short'] = 0
        
        # 進場條件優化：
        # 1. 價格高於 EMA200 (趨勢過濾)
        # 2. RSI 從 < 20 區間反轉向上超過 25 (避免鈍化刀子)
        # 3. 非美股開盤時間
        
        trend_ok = (dataframe['close'] > dataframe['ema200'])
        rsi_reversal = (dataframe['rsi_prev'] < 20) & (dataframe['rsi'] > 25)
        is_market_closed = ~dataframe['date'].apply(self.is_us_market_open)
        
        long_cond = (dataframe['rsi'].notna()) & trend_ok & rsi_reversal & is_market_closed
        
        dataframe.loc[long_cond, 'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['exit_long'] = 0
        dataframe['exit_short'] = 0
        return dataframe

    def custom_exit(self, pair: str, trade: 'Trade', current_time: datetime, current_rate: float,
                    current_profit: float, **kwargs) -> Optional[str]:
        # 獲利達到 10% 出場
        if current_profit >= 0.10:
            return 'profit_10_percent'
        return None

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: Optional[str],
                 side: str, **kwargs) -> float:
        return 10.0