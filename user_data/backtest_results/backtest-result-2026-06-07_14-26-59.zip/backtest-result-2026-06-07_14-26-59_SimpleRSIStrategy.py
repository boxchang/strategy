import numpy as np
import pandas as pd
from pandas import DataFrame
from datetime import datetime, time
from typing import Optional
import talib.abstract as ta
import logging
from freqtrade.strategy import IStrategy, IntParameter

logger = logging.getLogger(__name__)

class SimpleRSIStrategy(IStrategy):
    INTERFACE_VERSION = 3
    timeframe = '15m'
    can_short = False
    
    # 改用動態計算停損，不使用固定的 stoploss 百分比
    # 這裡設定停損由 custom_stoploss 函數決定
    use_custom_stoploss = True
    
    startup_candle_count = 200
    
    tradable_balance_ratio = 0.99
    trailing_stop = True
    trailing_stop_positive = 0.05
    trailing_stop_positive_offset = 0.08
    trailing_only_offset_is_reached = True

    buy_rsi = IntParameter(5, 50, default=20, space="buy", optimize=True)

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=6)
        dataframe['ema200'] = ta.EMA(dataframe, timeperiod=200)
        dataframe['atr'] = ta.ATR(dataframe, timeperiod=14)
        dataframe['rsi_prev'] = dataframe['rsi'].shift(1)
        return dataframe

    def custom_stoploss(self, pair: str, trade: 'Trade', current_time: datetime,
                        current_rate: float, current_profit: float, **kwargs) -> float:
        # 修正：直接從 DataProvider 取得已計算好指標的完整 DataFrame
        dataframe = self.dp.get_pair_dataframe(pair, self.timeframe)
        if dataframe.empty or 'atr' not in dataframe.columns:
            return 0.10 # 若資料不足則返回預設值

        atr_value = dataframe.iloc[-1]['atr']
        stoploss_pct = (atr_value * 3) / current_rate
        return min(max(stoploss_pct, 0.03), 0.10) # 停損範圍限制在 3% - 10% 之間

    def is_us_market_open(self, current_time: datetime) -> bool:
        time_utc = current_time.time()
        return time(14, 30) <= time_utc < time(21, 0)

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['enter_long'] = 0
        
        # 邏輯：直接在極度超賣 (RSI < 20) 進場
        # 加入波動率濾網：ATR 必須大於某個門檻，避免在死魚盤中進場
        # 加入非美股開盤時間濾網
        
        # 連續兩根 RSI < 20 表示市場極度恐慌，有利於反轉
        rsi_low = (dataframe['rsi'] < 20) & (dataframe['rsi'].shift(1) < 20)
        
        is_market_closed = ~dataframe['date'].apply(self.is_us_market_open)
        
        # 移除 EMA 過濾，讓進場更積極
        long_cond = (dataframe['rsi'].notna()) & rsi_low & is_market_closed
        
        dataframe.loc[long_cond, 'enter_long'] = 1
        return dataframe
        
    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['exit_long'] = 0
        return dataframe

    def custom_exit(self, pair: str, trade: 'Trade', current_time: datetime, current_rate: float,
                    current_profit: float, **kwargs) -> Optional[str]:
        if current_profit >= 0.10:
            return 'profit_10_percent'
        return None

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: Optional[str],
                 side: str, **kwargs) -> float:
        return 10.0