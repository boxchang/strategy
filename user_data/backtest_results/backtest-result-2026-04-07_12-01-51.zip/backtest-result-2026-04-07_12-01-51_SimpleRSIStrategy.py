from freqtrade.strategy import IStrategy
from pandas import DataFrame
import talib.abstract as ta

class SimpleRSIStrategy(IStrategy):
    # 策略的时间框架，这里使用 15 分钟 K 线
    timeframe = '15m'

    # 止损设置为 -10%，意味着价格下跌 10% 时自动平仓
    stoploss = -0.10

    # 最小收益目标：当盈利达到 1% 时立即平仓
    minimal_roi = {
        "0": 0.01  # 0 分钟（即立即）达到 1% 盈利就平仓
    }

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 计算 RSI 指标，时间周期为 14
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 当 RSI 小于 30 时产生买入信号
        dataframe.loc[
            (dataframe['rsi'] < 30),
            'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 当 RSI 大于 70 时产生卖出信号
        dataframe.loc[
            (dataframe['rsi'] > 70),
            'exit_long'] = 1
        return dataframe