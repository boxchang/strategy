import numpy as np
import pandas as pd
from pandas import DataFrame
from datetime import datetime
from typing import Optional
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib
from freqtrade.strategy import IStrategy, IntParameter

class SimpleRSIStrategy(IStrategy):
    """
    RSI 雙向極速交易策略 - 修改版
    - Short 條件: EMA(7) < EMA(99) 且 RSI < 10
    - 止損: 10%
    - 移動獲利: 獲利 8% 啟動，回撤至 5% 平倉
    """
    INTERFACE_VERSION = 3
    timeframe = '15m'
    can_short = True
    
    # 止損 10%
    stoploss = -0.10

    # 移動獲利設定
    trailing_stop = True
    trailing_stop_positive = 0.05
    trailing_stop_positive_offset = 0.08
    trailing_only_offset_is_reached = True

    # 參數設定
    buy_rsi = IntParameter(5, 20, default=10, space="buy", optimize=True)

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['ema7'] = ta.EMA(dataframe, timeperiod=7)
        dataframe['ema99'] = ta.EMA(dataframe, timeperiod=99)
        
        # 時間處理邏輯 (美東時間 08:30 - 17:00)
        dates_utc = dataframe['date'].dt.tz_localize('UTC') if dataframe['date'].dt.tz is None else dataframe['date'].dt.tz_convert('UTC')
        years = dates_utc.dt.year
        # 簡單判斷夏令時 (簡易版)
        is_dst = ((dates_utc.dt.month > 3) & (dates_utc.dt.month < 11))
        est_dates = np.where(is_dst, dates_utc - pd.to_timedelta(4, unit='h'), dates_utc - pd.to_timedelta(5, unit='h'))
        est_series = pd.Series(est_dates)
        
        is_market_hours = (
            ((est_series.dt.hour == 8) & (est_series.dt.minute >= 30)) |
            ((est_series.dt.hour >= 9) & (est_series.dt.hour < 17))
        )
        dataframe['us_market_active'] = np.where(is_market_hours & (est_series.dt.weekday < 5), 1, 0)
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['enter_long'] = 0
        dataframe['enter_short'] = 0

        # Short 條件: EMA7 < EMA99 且 RSI < 10 且在交易時段內
        short_cond = (
            (dataframe['ema7'] < dataframe['ema99']) &
            (dataframe['rsi'] < self.buy_rsi.value) &
            (dataframe['us_market_active'] == 1)
        )
        dataframe.loc[short_cond, 'enter_short'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['exit_long'] = 0
        dataframe['exit_short'] = 0
        return dataframe

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: Optional[str],
                 side: str, **kwargs) -> float:
        return 10.0