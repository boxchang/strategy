# pragma pylint: disable=missing-docstring, invalid-name, pointless-string-statement
# isort: skip_file
import numpy as np
import pandas as pd
from datetime import datetime
from typing import Optional
from freqtrade.strategy import IStrategy, IntParameter
from freqtrade.persistence import Trade
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib

class LucyStrategy(IStrategy):
    """
    LucyStrategy:
    - 只在美國週休不開盤的時候 (星期六、星期日) 進場。
    - Long: RSI < 10 時做多。
    - Short: RSI > 90 時做空。
    - 出場: 只要獲利達到 5 USDT 即刻平倉。
    """
    
    INTERFACE_VERSION = 3

    # 允許做空
    can_short = True

    # 禁用 ROI 平倉 (因為我們改用 custom_exit 做絕對金額獲利停利)
    minimal_roi = {
        "0": 100.0  
    }
    stoploss = -0.99 

    # 預設 K 線週期
    timeframe = '15m'

    # --- Hyperopt 參數設定 ---
    leverage_param = IntParameter(1, 50, default=20, space='buy', optimize=True)
    
    # RSI 參數
    rsi_entry_long = IntParameter(5, 20, default=10, space='buy', optimize=True)
    rsi_entry_short = IntParameter(80, 95, default=90, space='buy', optimize=True)

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: Optional[str],
                 side: str, **kwargs) -> float:
        return float(self.leverage_param.value)

    def custom_exit(self, pair: str, trade: Trade, current_time: datetime, current_rate: float,
                    current_profit: float, **kwargs):
        """
        只要獲利達到 5 USDT 就平倉
        使用 trade.calc_profit(current_rate) 來計算絕對獲利金額
        """
        # 計算當前匯率下的絕對獲利 (USDT)
        profit_abs = trade.calc_profit(current_rate)
        
        if profit_abs >= 5.0:
            return "ProfitTarget_5USDT"
        return None

    def populate_indicators(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['dayofweek'] = dataframe['date'].dt.dayofweek
        return dataframe

    def populate_entry_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        # Long: 週末且 RSI < 10
        long_condition = (
            (dataframe['dayofweek'].isin([5, 6])) & 
            (dataframe['rsi'] < self.rsi_entry_long.value)
        )
        dataframe.loc[long_condition, 'enter_long'] = 1

        # Short: 週末且 RSI > 90
        short_condition = (
            (dataframe['dayofweek'].isin([5, 6])) & 
            (dataframe['rsi'] > self.rsi_entry_short.value)
        )
        dataframe.loc[short_condition, 'enter_short'] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        # 這裡不需要複雜的 RSI 出場邏輯，主要交給 custom_exit 處理
        dataframe['exit_long'] = 0
        dataframe['exit_short'] = 0
        return dataframe