import numpy as np
import pandas as pd
from pandas import DataFrame
from datetime import datetime, time
from typing import Optional
import talib.abstract as ta
import logging
from freqtrade.strategy import IStrategy, IntParameter

logger = logging.getLogger(__name__)

class SimpleRSIStrategy(IStrategy):
    INTERFACE_VERSION = 3
    timeframe = '15m'
    can_short = False
    
    # 簡化並固定停損，避免過度依賴計算指標
    stoploss = -0.04 
    use_custom_stoploss = False
    
    startup_candle_count = 20
    
    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 單純 RSI + 布林通道，尋找極端超賣的反彈
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=6)
        bollinger = ta.BBANDS(dataframe, timeperiod=20, nbdevup=2.0, nbdevdn=2.0)
        dataframe['bb_lower'] = bollinger['lowerband']
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 進場條件：RSI < 20 且 價格觸及布林下軌
        # 這能過濾掉「緩慢下跌」的盤，精準捕捉「恐慌拋售」
        long_cond = (dataframe['rsi'] < 20) & (dataframe['close'] <= dataframe['bb_lower'])
        dataframe.loc[long_cond, 'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 出場條件：RSI 回升至 50 (回到中性區間)
        exit_long_cond = (dataframe['rsi'] > 50)
        dataframe.loc[exit_long_cond, 'exit_long'] = 1
        return dataframe

    def custom_exit(self, pair: str, trade: 'Trade', current_time: datetime, current_rate: float,
                    current_profit: float, **kwargs) -> Optional[str]:
        # 獲利 8% 獲利了結
        if current_profit >= 0.08:
            return 'profit_8_percent'
        return None

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: Optional[str],
                 side: str, **kwargs) -> float:
        return 5.0 # 降低槓桿以減少單次波動影響