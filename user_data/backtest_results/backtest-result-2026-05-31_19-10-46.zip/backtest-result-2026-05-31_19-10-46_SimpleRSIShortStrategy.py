import numpy as np
import pandas as pd
from pandas import DataFrame
from datetime import datetime
from typing import Optional, Union

from freqtrade.strategy import (
    BooleanParameter,
    CategoricalParameter,
    DecimalParameter,
    IStrategy,
    IntParameter,
)
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib


class SimpleRSIShortStrategy(IStrategy):
    """
    RSI 超過 80 做空策略
    - RSI > 80: 開啟 Short 倉位
    - 獲利達到 30% (ROI: 0.30) 或 觸發止損時出場
    """

    # 策略介面版本
    INTERFACE_VERSION = 3

    # 撮合與交易設定 (建議 15m 或 1h K線)
    timeframe = "1h"

    # 是否允許做多/做空 (依需求：只做空)
    can_short = True

    # -------------------------------------------------------------------------
    # 核心出場邏輯：獲利 30% 出場 (ROI = 0.3)
    # 0 代表持倉 0 分鐘以上，只要達到 30% 收益就立刻市價平倉
    # -------------------------------------------------------------------------
    minimal_roi = {"0": 0.30}

    # 強制止損百分比 (範例設為 -10%，可依個人風險承受度調整)
    stoploss = -0.10

    # 追蹤止損 (可選，預設關閉)
    trailing_stop = False

    # 執行訂單類型
    order_types = {
        "entry": "market",
        "exit": "market",
        "emergency_exit": "market",
        "force_entry": "market",
        "force_exit": "market",
        "stoploss": "market",
        "stoploss_on_exchange": False,
    }

    # 執行時間設定
    order_time_in_force = {"entry": "gtc", "exit": "gtc"}

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        計算技術指標：RSI
        """
        # 計算標準 14 週期的 RSI
        dataframe["rsi"] = ta.RSI(dataframe, timeperiod=14)

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        定義進場訊號 (RSI > 80 則 Short)
        """
        # 初始化進場欄位
        dataframe["enter_long"] = 0
        dataframe["enter_tag"] = ""

        # --- Short (做空) 進場邏輯 ---
        # 條件：當前 K 線的 RSI 大於 80
        dataframe.loc[
            (dataframe["rsi"] > 80)
            & (dataframe["volume"] > 0),  # 確保該 K 線有交易量
            ["enter_short", "enter_tag"],
        ] = (1, "rsi_overbought_short")

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        定義技術指標出場訊號 (由於已使用 minimal_roi 控制 30% 獲利，這裡保持預設不留指標出場)
        """
        dataframe["exit_long"] = 0
        dataframe["exit_short"] = 0
        dataframe["exit_tag"] = ""

        return dataframe