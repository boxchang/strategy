import logging
import numpy as np
import pandas as pd
from pandas import DataFrame
import pandas_ta as pta
from freqtrade.strategy import IStrategy, IntParameter

# 建立 Logger 物件以在控制台印出 Log
logger = logging.getLogger(__name__)

class HighRsiShortDcaStrategy(IStrategy):
    """
    4h Short-Only Strategy with Hyperoptable RSI Parameters
    - RSI Entry > rsi_buy_level (可優化範圍 70-95)
    - RSI Exit < rsi_sell_level (可優化範圍 10-40)
    - RSI Period = rsi_period (可優化範圍 7-21)
    """

    # 策略基本設定
    timeframe = '4h'
    can_short = True
    
    stoploss = -1.0

    minimal_roi = {
        "0": 0.10
    }
    
    position_adjustment_enable = True
    max_entry_position_adjustment = 3

    # ==================== 可優化參數定義 ====================
    # RSI 週期，預設 14，範圍 7 到 21
    rsi_period = IntParameter(7, 21, default=14, space='buy', optimize=True)
    
    # 做空進場觸發點（RSI 高於此值進場），預設 90，範圍 70 到 95
    rsi_short_entry = IntParameter(70, 95, default=90, space='buy', optimize=True)
    
    # 做空平倉出場點（RSI 低於此值出場），預設 25，範圍 10 到 40
    rsi_short_exit = IntParameter(10, 40, default=25, space='sell', optimize=True)
    # ========================================================

    def leverage(self, pair: str, current_time: str, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: str,
                 side: str, **kwargs) -> float:
        return 10.0

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """計算不同週期的 RSI 指標"""
        # 如果開啟 Hyperopt 尋找最佳週期，會依據當前的 rsi_period 動態計算
        dataframe['rsi'] = pta.rsi(dataframe['close'], length=self.rsi_period.value)
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """進場條件：價格 > 100 且 RSI > rsi_short_entry 時做空"""
        dataframe.loc[
            (
                (dataframe['close'] > 95) &
                (dataframe['rsi'] > self.rsi_short_entry.value) &
                (dataframe['volume'] > 0)
            ),
            'enter_short'] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """出場條件：RSI < rsi_short_exit 時平倉出局"""
        dataframe.loc[
            (
                (dataframe['rsi'] < self.rsi_short_exit.value) &
                (dataframe['volume'] > 0)
            ),
            'exit_short'] = 1

        return dataframe

    def adjust_trade_position(self, trade, current_time, current_rate: float,
                              current_profit: float, min_stake: float,
                              max_stake: float, **kwargs):
        """
        DCA 補倉邏輯與日誌記錄
        """
        # 取得已發生的成功進場/加倉次數（初始進場算 1）
        current_entry_count = trade.nr_of_successful_entries - 1

        # 僅在虧損達到 100% (ROE <= -100%) 時觸發加倉
        if current_profit > -0.9:
            return None

        # 檢查是否已達到最大加倉次數限制 (3次)
        if current_entry_count >= self.max_entry_position_adjustment:
            logger.info(
                f"[{trade.pair}] 虧損達 {current_profit:.2%}，但已達最大補倉上限 ({current_entry_count}/{self.max_entry_position_adjustment})"
            )
            return None

        # 計算欲加倉金額（當前持倉數量的 2 倍金額）
        desired_stake_amount = (trade.amount * 2) * current_rate

        # 資金門檻檢查
        if max_stake is not None and desired_stake_amount > max_stake:
            desired_stake_amount = max_stake

        if min_stake is not None and desired_stake_amount < min_stake:
            logger.warning(
                f"[{trade.pair}] 欲加倉金額 {desired_stake_amount:.2f} 低於交易所最小門檻 {min_stake}"
            )
            return None

        # 🔍 輸出補倉日誌 (Console Logs)
        logger.info(
            f"=== 觸發 DCA 補倉 ===\n"
            f"▸ 標的: {trade.pair}\n"
            f"▸ 時間: {current_time}\n"
            f"▸ 當前虧損率 (ROE): {current_profit:.2%}\n"
            f"▸ 補倉前次數: {current_entry_count} / {self.max_entry_position_adjustment}\n"
            f"▸ 補倉前數量 (Amount): {trade.amount:.4f}\n"
            f"▸ 補倉前均價 (Open Rate): {trade.open_rate:.4f}\n"
            f"▸ 當前市場價格: {current_rate:.4f}\n"
            f"▸ 預計加倉金額 (Stake): {desired_stake_amount:.2f} USDT\n"
            f"========================"
        )

        return desired_stake_amount