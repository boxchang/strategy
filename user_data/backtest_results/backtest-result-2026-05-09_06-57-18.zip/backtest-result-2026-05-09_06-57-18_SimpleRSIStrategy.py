from freqtrade.strategy.interface import IStrategy
from pandas import DataFrame
import talib.abstract as ta
from datetime import timedelta

class SimpleRSIStrategy(IStrategy):
    # 啟用加倉功能
    position_adjustment_enable = False

    # 使用 5 分鐘 K 線
    timeframe = '15m'

    informative_timeframes = {
        "1h": "1h"
    }

    leverage = 5

    # ROI 設定：分段獲利目標
    minimal_roi = {
        "0": 0.03,   # 立即獲利目標 3%
        "30": 0.02,  # 30 分鐘後降到 2%
        "60": 0.01   # 60 分鐘後降到 1%
    }

    # 止損設定
    stoploss = -0.02   # 最大虧損 2%

    # 移動停損
    trailing_stop = True
    trailing_stop_positive = 0.01
    trailing_stop_positive_offset = 0.02
    trailing_only_offset_is_reached = True

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # RSI 指標
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)

        informative = self.dp.get_pair_dataframe(
            pair=metadata['pair'],
            timeframe="1h"
        )

        informative['ma7_1h'] = ta.SMA(informative, timeperiod=7)
        informative['ma20_1h'] = ta.SMA(informative, timeperiod=20)

        # 合併到主 dataframe
        dataframe = dataframe.merge(
            informative[['date', 'ma7_1h', 'ma20_1h']],
            on='date',
            how='left'
        )

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (dataframe['rsi'] < 30) &
            (dataframe['ma7_1h'] > dataframe['ma20_1h']),
            'enter_long'
        ] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (dataframe['ma7_1h'] < dataframe['ma20_1h']),
            'exit_long'
        ] = 1
        return dataframe
