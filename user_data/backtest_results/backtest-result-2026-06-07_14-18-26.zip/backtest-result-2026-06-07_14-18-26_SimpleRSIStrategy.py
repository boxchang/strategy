import numpy as np
import pandas as pd
from pandas import DataFrame
from datetime import datetime, time
from typing import Optional
import talib.abstract as ta
import logging
from freqtrade.strategy import IStrategy, IntParameter

logger = logging.getLogger(__name__)

class SimpleRSIStrategy(IStrategy):
    INTERFACE_VERSION = 3
    timeframe = '15m'
    can_short = True
    stoploss = -0.10
    
    startup_candle_count = 20
    
    tradable_balance_ratio = 0.99
    trailing_stop = True
    trailing_stop_positive = 0.05
    trailing_stop_positive_offset = 0.08
    trailing_only_offset_is_reached = True

    buy_rsi = IntParameter(5, 50, default=20, space="buy", optimize=True)

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 計算 RSI
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=6)
        
        return dataframe

    def is_us_market_open(self, current_time: datetime) -> bool:
        """
        判斷是否為美股開盤時間 (ET 09:30 - 16:00)
        轉換為 UTC 判斷：
        美股開盤 (09:30 ET) = 14:30 UTC
        美股收盤 (16:00 ET) = 21:00 UTC
        """
        # 轉換為 UTC 時間
        time_utc = current_time.time()
        # 判斷是否在 14:30 UTC 到 21:00 UTC 之間
        return time(14, 30) <= time_utc < time(21, 0)

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['enter_long'] = 0
        dataframe['enter_short'] = 0
        
        # 定義進場條件: RSI < 20
        long_cond = (dataframe['rsi'].notna()) & (dataframe['rsi'] < 20)
        
        # 新增條件: 檢查該時間點是否為美股開盤時間
        # 我們只在 "非美股開盤時間" 買入，因此使用 not is_us_market_open
        dataframe['is_market_open'] = dataframe['date'].apply(self.is_us_market_open)
        
        final_long_cond = long_cond & (~dataframe['is_market_open'])
        
        dataframe.loc[final_long_cond, 'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['exit_long'] = 0
        dataframe['exit_short'] = 0
        
        return dataframe

    def custom_exit(self, pair: str, trade: 'Trade', current_time: datetime, current_rate: float,
                    current_profit: float, **kwargs) -> Optional[str]:
        # 當獲利達到 10% 時出場
        if current_profit >= 0.10:
            return 'profit_10_percent'
        return None

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: Optional[str],
                 side: str, **kwargs) -> float:
        return 10.0