from freqtrade.strategy.interface import IStrategy
from pandas import DataFrame
import talib.abstract as ta
from datetime import datetime
from typing import Optional
import logging

class SimpleRSIStrategy(IStrategy):
    logger = logging.getLogger(__name__)
    position_adjustment_enable = True   # 開啟加倉功能
    timeframe = '15m'
    leverage_value = 15.0
    can_short = True
    max_entry_position_adjustment = 10
    minimal_roi = {
        "0": 0.2,
        "30": 0.15,
        "60": 0.1
    }

    stoploss = -0.99

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['rsi'] = ta.RSI(dataframe['close'], timeperiod=14)
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (dataframe['rsi'] < 30),
            ['enter_long', 'enter_tag']
        ] = (1, 'rsi_long')

        dataframe.loc[
            (dataframe['rsi'] > 80),
            ['enter_short', 'enter_tag']
        ] = (1, 'rsi_short')

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (dataframe['rsi'] > 80),
            ['exit_long', 'exit_tag']
        ] = (1, 'rsi_exit_long')

        dataframe.loc[
            (dataframe['rsi'] < 30),
            ['exit_short', 'exit_tag']
        ] = (1, 'rsi_exit_short')

        return dataframe

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: Optional[str],
                 side: str, **kwargs) -> float:
        return self.leverage_value

    def adjust_trade_position(
            self,
            trade,
            current_time: datetime,
            current_rate: float,
            current_profit: float,
            min_stake: float | None,
            max_stake: float,
            current_entry_rate: float,
            current_exit_rate: float,
            current_entry_profit: float,
            current_exit_profit: float,
            **kwargs
    ):

        if trade.date_last_filled_utc:
            seconds = (current_time - trade.date_last_filled_utc).total_seconds()

            # 距離上次成交不到 5 分鐘，不補倉
            if seconds < 5 * 60:
                return None

        self.logger.info(
            f"Adjust called: {trade.pair}, profit={current_profit:.4f}, "
            f"entries={trade.nr_of_successful_entries}"
        )

        if current_profit <= -0.45 and trade.nr_of_successful_entries < 4:
            stake = min(100, max_stake)
            return stake, "test_dca"
        elif current_profit <= -0.6 and trade.nr_of_successful_entries < 7:
            stake = min(150, max_stake)
            return stake, "test_dca"
        elif current_profit <= -0.7 and trade.nr_of_successful_entries < 11:
            stake = min(200, max_stake)
            return stake, "test_dca"

        return None
