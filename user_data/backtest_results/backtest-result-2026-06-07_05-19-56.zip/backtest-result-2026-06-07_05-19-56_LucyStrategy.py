# pragma pylint: disable=missing-docstring, invalid-name, pointless-string-statement
# isort: skip_file
import numpy as np
import pandas as pd
from datetime import datetime
from typing import Optional
from freqtrade.strategy import IStrategy, IntParameter
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib

class LucyStrategy(IStrategy):
    """
    LucyStrategy:
    - 只做多 (Long Only)。
    - 在美國週休不開盤的時候 (星期六、星期日)，RSI < 30 時做多 (買進)。
    - 獲利達到 10% 即刻賣出 (透過 minimal_roi)。
    - 任何時候 RSI > 80 時提早平倉 (作為除了 10% 停利之外的技術指標提早出場)。
    """
    
    # 策略介面版本
    INTERFACE_VERSION = 3

    # 改為不允許做空 (只做多)
    can_short = False

    # 預設的 Minimal ROI (投資回報率) 與 Stoploss (止損)
    # 設定為獲利 10% (0.1) 就平倉
    minimal_roi = {
        "0": 0.1  # 只要獲利達到 10% 就立即賣出
    }
    stoploss = -0.99  # 寬鬆止損

    # 預設 K 線週期 (Timeframe)，更改為 15m
    timeframe = '15m'

    # --- Hyperopt 參數設定 ---
    # 槓桿參數 (預設 20，範圍 1~50)
    leverage_param = IntParameter(1, 50, default=20, space='buy', optimize=True)
    
    # RSI 進場參數 (只保留做多)
    rsi_entry_long = IntParameter(10, 45, default=30, space='buy', optimize=True)
    
    # RSI 出場參數 (只保留做多)
    rsi_exit_long = IntParameter(55, 95, default=80, space='sell', optimize=True)

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: Optional[str],
                 side: str, **kwargs) -> float:
        """
        設定策略槓桿倍數
        使用 leverage_param 參數，支援 Hyperopt 尋找最佳槓桿
        """
        return float(self.leverage_param.value)

    def populate_indicators(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        """
        計算技術指標
        """
        # 計算 RSI，預設週期為 14
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        
        # 取得星期幾 (0 是星期一，5 是星期六，6 是星期日)
        # Freqtrade 的時間預設為 UTC。星期六和星期日(UTC)完美落在美國傳統市場(美股)的週末休市期間。
        dataframe['dayofweek'] = dataframe['date'].dt.dayofweek
        
        return dataframe

    def populate_entry_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        """
        設定進場條件 (做多)
        """
        # 做多條件：週末 (星期六、星期日) 且 RSI 小於最佳化參數
        long_condition = (
            (dataframe['dayofweek'].isin([5, 6])) & 
            (dataframe['rsi'] < self.rsi_entry_long.value)
        )
        dataframe.loc[long_condition, 'enter_long'] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        """
        設定出場條件 (平多)
        """
        # 平多條件 (賣出)：RSI 大於最佳化參數 (作為除了 10% 停利之外的技術指標提早出場)
        exit_long_condition = (
            (dataframe['rsi'] > self.rsi_exit_long.value)
        )
        dataframe.loc[exit_long_condition, 'exit_long'] = 1

        return dataframe