from freqtrade.strategy.interface import IStrategy
from pandas import DataFrame
import talib.abstract as ta

class SimpleRSIStrategy(IStrategy):
    # 啟用加倉功能
    position_adjustment_enable = True

    # 使用 5 分鐘 K 線
    timeframe = '5m'

    # ROI 設定：分段獲利目標
    minimal_roi = {
        "0": 0.03,   # 立即獲利目標 3%
        "30": 0.02,  # 30 分鐘後降到 2%
        "60": 0.01   # 60 分鐘後降到 1%
    }

    # 止損設定
    stoploss = -0.15   # 最大虧損 2%

    # 移動停損
    trailing_stop = True
    trailing_stop_positive = 0.01
    trailing_stop_positive_offset = 0.02
    trailing_only_offset_is_reached = True

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # RSI 指標
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # RSI < 30 → 超賣，進場買入
        dataframe.loc[
            (dataframe['rsi'] > 70),
            'enter_long'
        ] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # RSI > 70 → 超買，出場賣出
        dataframe.loc[
            (dataframe['rsi'] < 20),
            'exit_long'
        ] = 1
        return dataframe
        
    def adjust_trade_position(self, trade, current_time, current_rate, current_profit, **kwargs):
        """
        分批加倉邏輯：
        - 第一次：200 USDT（由 stake_amount 控制）
        - 第二次：如果虧損超過 -5%，加倉 100 USDT
        - 第三次：如果虧損超過 -10%，再加倉 50 USDT
        """
        # 已加倉次數
        num_entries = len(trade.orders)

        if num_entries == 1 and current_profit < -0.05:
            return 10  # 第二次加倉
        elif num_entries == 2 and current_profit < -0.10:
            return 5   # 第三次加倉
        else:
            return 0    # 不加倉