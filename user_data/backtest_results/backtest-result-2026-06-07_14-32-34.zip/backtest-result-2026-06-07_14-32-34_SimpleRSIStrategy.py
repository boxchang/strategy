import numpy as np
import pandas as pd
from pandas import DataFrame
from datetime import datetime, timezone
from typing import Optional, Union
import logging

from freqtrade.strategy import (
    IStrategy,
    DecimalParameter,
    IntParameter,
    BooleanParameter,
)
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib


class SimpleRSIStrategy(IStrategy):
    """
    RSI 雙向極速交易策略 (15x 槓桿 + 三階層虧損加倉防禦版 - 專業美股時間過濾與放量突破版)
    """

    logger = logging.getLogger(__name__)
    INTERFACE_VERSION = 3

    timeframe = '15m'
    can_short = True
    
    position_adjustment_enable = True
    max_entry_position_adjustment = 10

    stoploss = -0.12

    trailing_stop = True
    trailing_stop_positive = 0.05
    trailing_stop_positive_offset = 0.08
    trailing_only_offset_is_reached = True

    minimal_roi = {
        "0": 0.20,
        "30": 0.15,
        "60": 0.10
    }

    leverage_value = 10.0

    buy_rsi = IntParameter(20, 40, default=30, space="buy", optimize=True)
    sell_rsi = IntParameter(60, 90, default=80, space="sell", optimize=True)
    volume_multiplier = DecimalParameter(1.0, 3.0, default=1.5, decimals=1, space="buy", optimize=True)

    dca_stage1_profit = DecimalParameter(-0.55, -0.35, default=-0.45, decimals=2, space="buy", optimize=True)
    dca_stage2_profit = DecimalParameter(-0.68, -0.50, default=-0.60, decimals=2, space="buy", optimize=True)
    dca_stage3_profit = DecimalParameter(-0.85, -0.65, default=-0.70, decimals=2, space="buy", optimize=True)

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['ema200'] = ta.EMA(dataframe, timeperiod=200)
        dataframe['volume_ema'] = ta.EMA(dataframe['volume'], timeperiod=20)
        
        dates_utc = dataframe['date'].dt.tz_localize('UTC') if dataframe['date'].dt.tz is None else dataframe['date'].dt.tz_convert('UTC')
        years = dates_utc.dt.year
        march_8 = pd.to_datetime(years.astype(str) + '-03-08').dt.tz_localize('UTC')
        dst_start = march_8 + pd.to_timedelta((6 - march_8.dt.weekday) % 7, unit='D') + pd.to_timedelta(7, unit='h')
        nov_1 = pd.to_datetime(years.astype(str) + '-11-01').dt.tz_localize('UTC')
        dst_end = nov_1 + pd.to_timedelta((6 - nov_1.dt.weekday) % 7, unit='D') + pd.to_timedelta(6, unit='h')
        
        is_dst = (dates_utc >= dst_start) & (dates_utc < dst_end)
        est_dates = np.where(is_dst, dates_utc - pd.to_timedelta(4, unit='h'), dates_utc - pd.to_timedelta(5, unit='h'))
        est_series = pd.Series(est_dates)
        
        is_us_market_hours = (
            ((est_series.dt.hour == 8) & (est_series.dt.minute >= 30)) |
            ((est_series.dt.hour > 8) & (est_series.dt.hour < 16))
        )
        is_weekday = est_series.dt.weekday < 5
        dataframe['us_market_active'] = np.where(is_us_market_hours & is_weekday, 1, 0)
        
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['enter_long'] = 0
        dataframe['enter_short'] = 0
        dataframe['enter_tag'] = ''

        long_cond = (
            (dataframe['close'] > dataframe['ema200']) &
            (qtpylib.crossed_above(dataframe['rsi'], self.buy_rsi.value)) &
            (dataframe['volume'] > (dataframe['volume_ema'] * self.volume_multiplier.value)) &
            (dataframe['us_market_active'] == 1)
        )
        dataframe.loc[long_cond, ['enter_long', 'enter_tag']] = (1, 'rsi_ema_vol_us_long')

        short_cond = (
            (dataframe['close'] < dataframe['ema200']) &
            (qtpylib.crossed_below(dataframe['rsi'], self.sell_rsi.value)) &
            (dataframe['volume'] > (dataframe['volume_ema'] * self.volume_multiplier.value)) &
            (dataframe['us_market_active'] == 1)
        )
        dataframe.loc[short_cond, ['enter_short', 'enter_tag']] = (1, 'rsi_ema_vol_us_short')

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['exit_long'] = 0
        dataframe['exit_short'] = 0
        dataframe['exit_tag'] = ''

        dataframe.loc[(dataframe['rsi'] > self.sell_rsi.value), ['exit_long', 'exit_tag']] = (1, 'rsi_exit_long')
        dataframe.loc[(dataframe['rsi'] < self.buy_rsi.value), ['exit_short', 'exit_tag']] = (1, 'rsi_exit_short')

        return dataframe

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: Optional[str],
                 side: str, **kwargs) -> float:
        return self.leverage_value

    def adjust_trade_position(
            self,
            trade,
            current_time: datetime,
            current_rate: float,
            current_profit: float,
            min_stake: float | None,
            max_stake: float,
            current_entry_rate: float,
            current_exit_rate: float,
            current_entry_profit: float,
            current_exit_profit: float,
            **kwargs
    ):
        if trade.date_last_filled_utc:
            seconds = (current_time - trade.date_last_filled_utc).total_seconds()
            if seconds < 5 * 60:
                return None

        base_stake = self.config.get('stake_amount', 30)
        if isinstance(base_stake, str) or base_stake is None:
            base_stake = 30  

        # 修正：確保 min_stake 有合法值，避免 None 導致計算錯誤
        actual_min_stake = min_stake if min_stake is not None else 0.0

        stage1_config_stake = base_stake * 1.0
        stage2_config_stake = base_stake * 1.5
        stage3_config_stake = base_stake * 2.0
        
        if current_profit <= self.dca_stage1_profit.value and trade.nr_of_successful_entries < 4:
            stake = max(actual_min_stake, min(stage1_config_stake, max_stake))
            return stake, "test_dca_stage1"
            
        elif current_profit <= self.dca_stage2_profit.value and trade.nr_of_successful_entries < 7:
            stake = max(actual_min_stake, min(stage2_config_stake, max_stake))
            return stake, "test_dca_stage2"
            
        elif current_profit <= self.dca_stage3_profit.value and trade.nr_of_successful_entries < 11:
            stake = max(actual_min_stake, min(stage3_config_stake, max_stake))
            return stake, "test_dca_stage3"

        return None