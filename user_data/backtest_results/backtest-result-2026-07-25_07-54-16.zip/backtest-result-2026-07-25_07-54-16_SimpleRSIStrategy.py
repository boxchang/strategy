import numpy as np
import pandas as pd
from pandas import DataFrame
from datetime import datetime
from typing import Optional
import talib.abstract as ta
import logging
from freqtrade.strategy import IStrategy, IntParameter, DecimalParameter

logger = logging.getLogger(__name__)

class SimpleRSIStrategy(IStrategy):
    INTERFACE_VERSION = 3
    timeframe = '15m'
    can_short = False

    # 資金與加倉 (DCA) 控制
    position_adjustment_enable = True       # 必須設為 True 才能啟用自訂的加倉機制
    max_entry_position_adjustment = 10
    
    # 參數化設定
    buy_rsi = IntParameter(5, 30, default=20, space="buy", optimize=True)
    # 新增：RSI 出場門檻參數
    exit_rsi = IntParameter(70, 95, default=80, space="sell", optimize=True)
    
    # 新增：槓桿參數化 (範圍 1-10)
    leverage_val = IntParameter(1, 20, default=10, space="entry", optimize=True)
    
    profit_target = DecimalParameter(0.10, 0.50, default=0.30, space="sell", optimize=True)
    stoploss_val = DecimalParameter(0.10, 0.40, default=0.25, space="sell", optimize=True)

    # 參數化 Trailing Stop 設定
    trailing_stop = True
    # 當達到此獲利門檻時啟動追蹤
    trailing_stop_positive = DecimalParameter(0.01, 0.10, default=0.05, space="sell", optimize=True)
    # 當獲利回撤達到此數值時觸發賣出
    trailing_stop_positive_offset = DecimalParameter(0.02, 0.15, default=0.08, space="sell", optimize=True)
    trailing_only_offset_is_reached = True

    # 三階段 DCA 的虧損加倉觸發比例 (此處為合約帳戶「已槓桿」的浮動利潤虧損比例)
    # ⚠️ 注意：這三個優化上限（如 -0.85）在 10 倍槓桿下，對應標的價格下跌 8.5%。
    # 因此全域 stoploss 絕對不能設定得比 -0.095 還要淺，否則 Hyperopt 會優化出「看得到卻吃不到」的 DCA 階層。
    dca_stage1_profit = DecimalParameter(-0.55, -0.35, default=-0.45, decimals=2, space="buy", optimize=True)
    dca_stage2_profit = DecimalParameter(-0.68, -0.50, default=-0.60, decimals=2, space="buy", optimize=True)
    dca_stage3_profit = DecimalParameter(-0.85, -0.65, default=-0.70, decimals=2, space="buy", optimize=True)
    # =====================================================================

    # 資金管理
    tradable_balance_ratio = 0.99

    # 將停損參數化 (範圍設為 -40% 到 -10%，預設 -25%)
    stoploss_val = DecimalParameter(-0.80, -0.10, default=-0.8, space="sell", optimize=True)

    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self.stoploss = self.stoploss_val.value

    use_custom_stoploss = False
    startup_candle_count = 20
    
    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=6)
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['enter_long'] = 0
        rsi_low = (dataframe['rsi'] < self.buy_rsi.value)
        dataframe.loc[rsi_low, 'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['exit_long'] = 0
        
        # 當 RSI 超過設定的 exit_rsi 時觸發賣出
        rsi_high = (dataframe['rsi'] > self.exit_rsi.value)
        dataframe.loc[rsi_high, 'exit_long'] = 1
        return dataframe

    def custom_exit(self, pair: str, trade: 'Trade', current_time: datetime, current_rate: float,
                    current_profit: float, **kwargs) -> Optional[str]:
        if current_profit >= self.profit_target.value:
            return 'profit_target'
        return None

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: Optional[str],
                 side: str, **kwargs) -> float:
        # 使用參數化的槓桿數值
        return float(self.leverage_val.value)

    def adjust_trade_position(
                self,
                trade,
                current_time: datetime,
                current_rate: float,
                current_profit: float,
                min_stake: float | None,
                max_stake: float,
                current_entry_rate: float,
                current_exit_rate: float,
                current_entry_profit: float,
                current_exit_profit: float,
                **kwargs
        ):
            """
            動態防禦補倉機制 (DCA)：
            
            當前交易產生虧損時，透過 3 階段加倉拉低均價，提高解套與反彈獲利的機率。
            """
            if trade.nr_of_successful_entries >= self.max_entry_position_adjustment:
                return None

            # 1. 檢查冷卻時間：距離上一次補倉成交不滿 5 分鐘，拒絕加倉
            if trade.date_last_filled_utc:
                seconds = (current_time - trade.date_last_filled_utc).total_seconds()
                if seconds < 5 * 60:
                    return None
    
            # 2. 【安全守衛 1】可用資金防護：
            # 如果當前帳戶最大可追加資金 (max_stake) 已小於交易所規定的最小下單金額 (min_stake)，或小於等於 0，
            # 直接拒絕補倉，返回 None。這樣能徹底避免在高浮虧、高槓桿下計算出「負數補倉金額」而被誤判為部分平倉。
            if min_stake is not None and max_stake < min_stake:
                return None
            if max_stake <= 0:
                return None
    
            # 3. 獲取基礎注碼 (config_person.json 中的 stake_amount)
            base_stake = self.config.get('stake_amount', 30)
    
            # 安全防範：如果設定為 "unlimited" (字串) 則給予安全基礎值
            if isinstance(base_stake, str) or base_stake is None:
                base_stake = 30  
    
            # 4. 依據基礎注碼（base_stake）按比例去計算每一階的注碼
            stage1_config_stake = base_stake * 1.0 * 0.1 # 只用1/10的資金當加碼
            stage2_config_stake = base_stake * 1.5 * 0.1
            stage3_config_stake = base_stake * 2.0 * 0.1
            
            # 交易所最小下單限制 (用於下方的限制保護)
            min_s = min_stake if min_stake is not None else 0.0
            
            # 【第一階】：當前合約利潤 <= dca_stage1_profit 且 總成交次數 < 4
            # 【安全守衛 2】: 使用 max(min_s, min(...)) 確保回傳金額絕對是合法的正數，雙重保險！
            if current_profit <= self.dca_stage1_profit.value and trade.nr_of_successful_entries < 4:
                stake = max(min_s, min(stage1_config_stake, max_stake))
                return stake, "test_dca_stage1"
                
            # 【第二階】：當前合約利潤 <= dca_stage2_profit 且 總成交次數 < 7
            elif current_profit <= self.dca_stage2_profit.value and trade.nr_of_successful_entries < 7:
                stake = max(min_s, min(stage2_config_stake, max_stake))
                return stake, "test_dca_stage2"
                
            # 【第三階】：當前合約利潤 <= dca_stage3_profit 且 總成交次數 < 11
            elif current_profit <= self.dca_stage3_profit.value and trade.nr_of_successful_entries < 11:
                stake = max(min_s, min(stage3_config_stake, max_stake))
                return stake, "test_dca_stage3"
    
            return None