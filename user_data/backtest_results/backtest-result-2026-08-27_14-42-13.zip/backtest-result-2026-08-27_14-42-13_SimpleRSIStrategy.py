import numpy as np
import pandas as pd
from pandas import DataFrame
from datetime import datetime
from typing import Optional
import talib.abstract as ta
import logging
from freqtrade.strategy import IStrategy, IntParameter, DecimalParameter
from freqtrade.persistence import Trade

logger = logging.getLogger(__name__)

class SimpleRSIStrategy(IStrategy):
    INTERFACE_VERSION = 3
    timeframe = '15m'
    can_short = False

    # 資金與加倉 (DCA) 控制：將最大加倉次數降至 3 次，避免倉位過大
    position_adjustment_enable = True
    max_entry_position_adjustment = 3

    # 【主導出場機制】ROI 設定
    minimal_roi = {
        "0": 0.15,     # 瞬時獲利 15% 出場
        "60": 0.08,    # 1 小時獲利 8% 出場
        "180": 0.03,   # 3 小時獲利 3% 出場
        "360": 0.01    # 6 小時保本微利出場
    }

    # 參數化設定
    buy_rsi = IntParameter(5, 30, default=22, space="buy", optimize=True)
    exit_rsi = IntParameter(70, 95, default=80, space="sell", optimize=True)
    leverage_val = IntParameter(1, 5, default=2, space="entry", optimize=True)

    # 參數化 Trailing Stop
    trailing_stop = True
    trailing_stop_positive = DecimalParameter(0.01, 0.05, default=0.02, space="sell", optimize=True)
    trailing_stop_positive_offset = DecimalParameter(0.02, 0.10, default=0.04, space="sell", optimize=True)
    trailing_only_offset_is_reached = True

    # 資金管理與嚴格停損 (配合槓桿，硬停損設為 -12%)
    stoploss = -0.12
    use_custom_stoploss = False
    startup_candle_count = 200

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # RSI 指標
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=6)
        
        # 趨勢濾網：EMA 200 (確保只在大趨勢向上或震盪時進場)
        dataframe['ema_200'] = ta.EMA(dataframe, timeperiod=200)
        
        # 暴跌過濾：計算過去 1 小時 (4 根 15m K線) 的跌幅
        dataframe['roc_1h'] = ta.ROC(dataframe, timeperiod=4)

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['enter_long'] = 0

        # 1. RSI 超賣
        rsi_low = (dataframe['rsi'] < self.buy_rsi.value)
        # 2. 大趨勢濾網：價格高於 EMA 200 (非空頭市場)
        is_uptrend = (dataframe['close'] > dataframe['ema_200'])
        # 3. 防瀑布濾網：1小時內跌幅不大於 4%
        no_crash = (dataframe['roc_1h'] > -4.0)

        dataframe.loc[
            rsi_low & is_uptrend & no_crash,
            'enter_long'
        ] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['exit_long'] = 0
        # 將 exit_long 保持為 0，由 custom_exit 與 ROI/Trailing Stop 主導平倉
        # 避免在虧損狀態下因為 RSI 回升而賤賣
        return dataframe

    def custom_exit(self, pair: str, trade: Trade, current_time: datetime, current_rate: float,
                    current_profit: float, **kwargs) -> Optional[str]:
        
        # 1. 解套快跑機制 (DCA Escape Strategy)
        # 如果已經加倉過 (持倉次數 > 1)，目標不再是追求高獲利，而是只要小賺 (0.8%) 就立刻出場解套
        if trade.nr_of_successful_entries > 1 and current_profit >= 0.008:
            return "dca_break_even_exit"

        # 2. RSI 獲利平倉 (僅限於有獲利狀態 > 1.5% 時才允許 RSI 觸發出場)
        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        if not dataframe.empty:
            last_candle = dataframe.iloc[-1]
            if last_candle['rsi'] > self.exit_rsi.value and current_profit > 0.015:
                return "rsi_profit_exit"

        # 3. 時間停損：若持倉超過 8 小時且持續虧損 (-2% 以上)，果斷認賠釋放資金
        trade_duration = (current_time - trade.open_date_utc).total_seconds() / 60
        if trade_duration > 480 and current_profit < -0.02:
            return "time_stop_loss"

        return None

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: Optional[str],
                 side: str, **kwargs) -> float:
        return float(self.leverage_val.value)

    def adjust_trade_position(self, trade: Trade, current_time: datetime, current_rate: float,
                              current_profit: float, min_stake: float | None,
                              max_stake: float, **kwargs):
        # 達到最大加倉次數則不再加倉
        if trade.nr_of_successful_entries >= self.max_entry_position_adjustment:
            return None

        # 檢查冷卻時間 (至少間隔 5 分鐘)
        if trade.date_last_filled_utc:
            seconds = (current_time - trade.date_last_filled_utc).total_seconds()
            if seconds < 300:
                return None

        # 取得最新 K 線指標
        dataframe, _ = self.dp.get_analyzed_dataframe(trade.pair, self.timeframe)
        if dataframe.empty:
            return None
        last_rsi = dataframe.iloc[-1]['rsi']

        base_stake = self.config.get('stake_amount', 30)
        if isinstance(base_stake, str) or base_stake is None:
            base_stake = 30

        min_s = min_stake if min_stake is not None else 0.0

        # 合理的智能 DCA 加倉條件 (需同時滿足「跌幅」與「RSI再次超賣」)
        if current_profit <= -0.04 and last_rsi < 28 and trade.nr_of_successful_entries == 1:
            return max(min_s, min(base_stake * 0.5, max_stake)), "dca_stage1"
        elif current_profit <= -0.08 and last_rsi < 24 and trade.nr_of_successful_entries == 2:
            return max(min_s, min(base_stake * 0.75, max_stake)), "dca_stage2"
        elif current_profit <= -0.12 and last_rsi < 20 and trade.nr_of_successful_entries == 3:
            return max(min_s, min(base_stake * 1.0, max_stake)), "dca_stage3"

        return None