from freqtrade.strategy.interface import IStrategy
from pandas import DataFrame
import talib.abstract as ta

class SimpleRSIStrategy(IStrategy):
    position_adjustment_enable = False
    timeframe = '5m'
    leverage_value = 5.0

    minimal_roi = {
        "0": 0.03,
        "30": 0.02,
        "60": 0.01
    }

    stoploss = -0.02

    trailing_stop = True
    trailing_stop_positive = 0.01
    trailing_stop_positive_offset = 0.02
    trailing_only_offset_is_reached = True

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # RSI 指標
        dataframe['rsi'] = ta.RSI(dataframe['close'], timeperiod=14)

        # 成交量均線 (用來判斷大戶進場)
        dataframe['vol_ma20'] = ta.SMA(dataframe['volume'], timeperiod=20)

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 多單進場：RSI > 70 且 當前成交量 > 20期均量 (大戶進場)
        dataframe.loc[
            (dataframe['rsi'] > 70) &
            (dataframe['volume'] > dataframe['vol_ma20']),
            'enter_long'
        ] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 多單出場：RSI < 20 或 成交量萎縮
        dataframe.loc[
            (dataframe['rsi'] < 20) |
            (dataframe['volume'] < dataframe['vol_ma20']),
            'exit_long'
        ] = 1

        return dataframe
