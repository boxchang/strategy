import numpy as np
import pandas as pd
from pandas import DataFrame
from datetime import datetime, time, timedelta
from typing import Optional
import talib.abstract as ta
import logging
from freqtrade.strategy import IStrategy, IntParameter, DecimalParameter

logger = logging.getLogger(__name__)

class SimpleRSIStrategy(IStrategy):
    INTERFACE_VERSION = 3
    timeframe = '15m'
    can_short = False
    
    # 參數化設定
    buy_rsi = IntParameter(5, 30, default=20, space="buy", optimize=True)
    exit_rsi = IntParameter(30, 70, default=50, space="sell", optimize=True)
    profit_target = DecimalParameter(0.02, 0.15, default=0.08, space="sell", optimize=True)
    stoploss_val = DecimalParameter(0.02, 0.10, default=0.04, space="sell", optimize=True)

    # 修正：直接設定初始值，並在 __init__ 確保其生效
    stoploss = -0.04

    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self.stoploss = -self.stoploss_val.value

    use_custom_stoploss = False
    startup_candle_count = 20
    
    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=6)
        bollinger = ta.BBANDS(dataframe, timeperiod=20, nbdevup=2.0, nbdevdn=2.0)
        dataframe['bb_lower'] = bollinger['lowerband']
        return dataframe

    def is_allowed_time(self, current_time: datetime) -> bool:
        utc_time = current_time.time()
        pre_market = time(12, 30) <= utc_time < time(13, 30)
        post_market = time(20, 0) <= utc_time < time(21, 0)
        return pre_market or post_market

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['enter_long'] = 0
        rsi_low = (dataframe['rsi'] < self.buy_rsi.value)
        is_trading_time = dataframe['date'].apply(self.is_allowed_time)
        
        long_cond = rsi_low & is_trading_time
        dataframe.loc[long_cond, 'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        exit_long_cond = (dataframe['rsi'] > self.exit_rsi.value)
        dataframe.loc[exit_long_cond, 'exit_long'] = 1
        return dataframe

    def custom_exit(self, pair: str, trade: 'Trade', current_time: datetime, current_rate: float,
                    current_profit: float, **kwargs) -> Optional[str]:
        if current_profit >= self.profit_target.value:
            return 'profit_target'
        return None

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: Optional[str],
                 side: str, **kwargs) -> float:
        return 5.0