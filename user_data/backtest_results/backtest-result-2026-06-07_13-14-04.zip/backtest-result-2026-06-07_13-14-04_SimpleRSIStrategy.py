import numpy as np
import pandas as pd
from pandas import DataFrame
from datetime import datetime
from typing import Optional
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib
from freqtrade.strategy import IStrategy, IntParameter

class SimpleRSIStrategy(IStrategy):
    INTERFACE_VERSION = 3
    timeframe = '15m'
    can_short = True
    stoploss = -0.10
    
    # 增加資金使用率限制，確保回測時不會因為餘額不足被拒
    tradable_balance_ratio = 0.99

    trailing_stop = True
    trailing_stop_positive = 0.05
    trailing_stop_positive_offset = 0.08
    trailing_only_offset_is_reached = True

    buy_rsi = IntParameter(5, 30, default=10, space="buy", optimize=True)

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 計算 RSI
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        
        # 強制加入除錯欄位，在回測結果中可以驗證 RSI 數值
        dataframe['rsi_debug'] = dataframe['rsi']
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 確保初始化
        dataframe['enter_long'] = 0
        dataframe['enter_short'] = 0

        # Short 條件: RSI 小於設定值
        # 加入 notna() 檢查，排除開頭因為計算不足產生的 NaN 值
        short_cond = (
            (dataframe['rsi'].notna()) & 
            (dataframe['rsi'] < self.buy_rsi.value)
        )
        
        dataframe.loc[short_cond, 'enter_short'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['exit_long'] = 0
        dataframe['exit_short'] = 0
        return dataframe

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: Optional[str],
                 side: str, **kwargs) -> float:
        return 10.0