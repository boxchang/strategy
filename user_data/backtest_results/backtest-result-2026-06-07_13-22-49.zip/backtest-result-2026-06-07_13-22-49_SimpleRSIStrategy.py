import numpy as np
import pandas as pd
from pandas import DataFrame
from datetime import datetime
from typing import Optional
import talib.abstract as ta
from freqtrade.strategy import IStrategy, IntParameter

class SimpleRSIStrategy(IStrategy):
    INTERFACE_VERSION = 3
    timeframe = '15m'
    can_short = True
    stoploss = -0.10
    
    tradable_balance_ratio = 0.99
    trailing_stop = True
    trailing_stop_positive = 0.05
    trailing_stop_positive_offset = 0.08
    trailing_only_offset_is_reached = True

    buy_rsi = IntParameter(5, 30, default=10, space="buy", optimize=True)

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['debug_rsi'] = dataframe['rsi']
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['enter_long'] = 0
        dataframe['enter_short'] = 0

        # 在每一根 K 線進行判斷時，將 RSI 數值印出以便除錯
        # 注意：回測時數據量大，建議只觀察特定範圍
        for index, row in dataframe.iterrows():
            if pd.notna(row['rsi']):
                print(f"DEBUG: 時間 {row['date']} | RSI: {row['rsi']:.2f} | 觸發Short: {row['rsi'] < self.buy_rsi.value}")

        # Short 條件: RSI < 10
        short_cond = (dataframe['rsi'].notna()) & (dataframe['rsi'] < self.buy_rsi.value)
        
        dataframe.loc[short_cond, 'enter_short'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['exit_long'] = 0
        dataframe['exit_short'] = 0
        return dataframe

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: Optional[str],
                 side: str, **kwargs) -> float:
        return 10.0