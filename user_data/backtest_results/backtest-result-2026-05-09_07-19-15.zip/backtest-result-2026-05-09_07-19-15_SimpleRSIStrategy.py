from freqtrade.strategy.interface import IStrategy
from pandas import DataFrame
import talib.abstract as ta
from datetime import timedelta

class SimpleRSIStrategy(IStrategy):
    position_adjustment_enable = False
    timeframe = '5m'

    informative_timeframes = {
        "1h": "1h"
    }

    leverage = 5
    can_short = True   # ★ 開啟做空功能

    minimal_roi = {
        "0": 0.03,
        "30": 0.02,
        "60": 0.01
    }

    stoploss = -0.02

    trailing_stop = True
    trailing_stop_positive = 0.01
    trailing_stop_positive_offset = 0.02
    trailing_only_offset_is_reached = True

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)

        informative = self.dp.get_pair_dataframe(
            pair=metadata['pair'],
            timeframe="1h"
        )
        informative['ma7'] = ta.SMA(informative, timeperiod=7)
        informative['ma20'] = ta.SMA(informative, timeperiod=20)

        dataframe = dataframe.merge(
            informative[['date', 'ma7', 'ma20']],
            on='date',
            how='left'
        )
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 多單進場：RSI > 80 且 MA7 > MA20
        dataframe.loc[
            (dataframe['rsi'] > 80) &
            (dataframe['ma7'] > dataframe['ma20']),
            'enter_long'
        ] = 1

        # 空單進場：RSI < 20 且 MA7 < MA20
        dataframe.loc[
            (dataframe['rsi'] < 20) &
            (dataframe['ma7'] < dataframe['ma20']),
            'enter_short'
        ] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 多單出場：MA7 < MA20
        dataframe.loc[
            (dataframe['ma7'] < dataframe['ma20']),
            'exit_long'
        ] = 1

        # 空單出場：MA7 > MA20
        dataframe.loc[
            (dataframe['ma7'] > dataframe['ma20']),
            'exit_short'
        ] = 1

        return dataframe