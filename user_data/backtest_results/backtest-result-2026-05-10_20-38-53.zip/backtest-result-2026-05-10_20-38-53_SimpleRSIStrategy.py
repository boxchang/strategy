from freqtrade.strategy.interface import IStrategy
from pandas import DataFrame
import talib.abstract as ta

class SimpleRSIStrategy(IStrategy):
    position_adjustment_enable = False
    timeframe = '5m'

    informative_timeframes = {
        "1h": "1h"
    }

    leverage = 5
    can_short = True   # ★ 開啟做空功能

    minimal_roi = {
        "0": 0.03,
        "30": 0.02,
        "60": 0.01
    }

    stoploss = -0.02

    trailing_stop = True
    trailing_stop_positive = 0.01
    trailing_stop_positive_offset = 0.02
    trailing_only_offset_is_reached = True

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # RSI 指標
        dataframe['rsi'] = ta.RSI(dataframe['close'], timeperiod=14)

        # 取得 1h 資料
        informative = self.dp.get_pair_dataframe(
            pair=metadata['pair'],
            timeframe="1h"
        )
        informative['ma7'] = ta.SMA(informative['close'], timeperiod=7)
        informative['ma20'] = ta.SMA(informative['close'], timeperiod=20)

        # 對齊時間索引，避免 merge 出錯
        informative = informative[['date', 'ma7', 'ma20']]
        dataframe = dataframe.merge(
            informative,
            on='date',
            how='left'
        )

        # 填補 NaN，避免後續判斷出錯
        dataframe[['ma7', 'ma20']] = dataframe[['ma7', 'ma20']].fillna(method='ffill')

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 多單進場：RSI > 70 且 MA7 > MA20
        dataframe.loc[
            (dataframe['rsi'] > 70) &
            (dataframe['ma7'] > dataframe['ma20']),
            'enter_long'
        ] = 1

        # 空單進場：RSI < 20 且 MA7 < MA20
        dataframe.loc[
            (dataframe['rsi'] < 20) &
            (dataframe['ma7'] < dataframe['ma20']),
            'enter_short'
        ] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 多單出場：MA7 < MA20
        dataframe.loc[
            (dataframe['ma7'] < dataframe['ma20']),
            'exit_long'
        ] = 1

        # 空單出場：MA7 > MA20
        dataframe.loc[
            (dataframe['ma7'] > dataframe['ma20']),
            'exit_short'
        ] = 1

        return dataframe
