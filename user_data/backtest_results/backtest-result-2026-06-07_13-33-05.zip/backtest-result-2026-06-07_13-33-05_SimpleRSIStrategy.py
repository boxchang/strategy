import numpy as np
import pandas as pd
from pandas import DataFrame
from datetime import datetime
from typing import Optional
import talib.abstract as ta
import logging
from freqtrade.strategy import IStrategy, IntParameter

logger = logging.getLogger(__name__)

class SimpleRSIStrategy(IStrategy):
    INTERFACE_VERSION = 3
    timeframe = '15m'
    can_short = True
    stoploss = -0.10
    
    tradable_balance_ratio = 0.99
    trailing_stop = True
    trailing_stop_positive = 0.05
    trailing_stop_positive_offset = 0.08
    trailing_only_offset_is_reached = True

    buy_rsi = IntParameter(5, 30, default=10, space="buy", optimize=True)

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 計算 RSI (確保使用 talib 且資料完整)
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        
        # 顯示時區轉換驗證
        try:
            vn_time = dataframe['date'].dt.tz_convert('Asia/Ho_Chi_Minh')
            logger.info(f"DEBUG: 前三筆 K 線時間 (越南時間): {vn_time.head(3).tolist()}")
        except Exception as e:
            logger.error(f"DEBUG: 時區轉換失敗: {e}")
        
        dataframe['debug_rsi'] = dataframe['rsi']
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['enter_long'] = 0
        dataframe['enter_short'] = 0

        # 在這裏印出每一次判斷時的 RSI，以便與 Binance 比對
        # 我們只輸出前 50 筆避免洗版，您可以調整數字
        for i in range(min(len(dataframe), 50)):
            row = dataframe.iloc[i]
            logger.info(f"DEBUG: 時間 {row['date']} | RSI: {row['rsi']:.2f} | 觸發Short: {row['rsi'] < self.buy_rsi.value}")

        # Short 條件: RSI < 10
        short_cond = (dataframe['rsi'].notna()) & (dataframe['rsi'] < self.buy_rsi.value)
        
        dataframe.loc[short_cond, 'enter_short'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['exit_long'] = 0
        dataframe['exit_short'] = 0
        return dataframe

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: Optional[str],
                 side: str, **kwargs) -> float:
        return 10.0