import numpy as np
import pandas as pd
from pandas import DataFrame
from datetime import datetime
from typing import Optional, Union

from freqtrade.strategy import (
    BooleanParameter,
    CategoricalParameter,
    DecimalParameter,
    IStrategy,
    IntParameter,
)
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib


class SimpleRSIShortStrategy(IStrategy):
    """
    RSI 超過特定值做空策略 (支援 Hyperopt 優化)
    - RSI > rsi_short_level: 開啟 Short 倉位
    - 獲利達到 30% (ROI: 0.30) 或 觸發止損時出場
    """

    # 策略介面版本
    INTERFACE_VERSION = 3

    # 撮合與交易設定 (建議 15m 或 1h K線)
    timeframe = "1h"
    leverage_value = 15.0
    # 是否允許做多/做空 (依需求：只做空)
    can_short = True

    # -------------------------------------------------------------------------
    # 核心出場邏輯：獲利 30% 出場 (ROI = 0.3)
    # -------------------------------------------------------------------------
    minimal_roi = {"0": 0.30}

    # 強制止損百分比
    stoploss = -1

    # 執行訂單類型
    order_types = {
        "entry": "market",
        "exit": "market",
        "emergency_exit": "market",
        "force_entry": "market",
        "force_exit": "market",
        "stoploss": "market",
        "stoploss_on_exchange": False,
    }

    order_time_in_force = {"entry": "gtc", "exit": "gtc"}

    # -------------------------------------------------------------------------
    # ⚙️ Hyperopt 參數定義區
    # -------------------------------------------------------------------------
    # 1. RSI 的計算週期：調整範圍 5 到 30，預設值為 14
    rsi_period = IntParameter(5, 30, default=14, space="buy", optimize=True)
    
    # 2. RSI 做空的超買門檻值：調整範圍 70 到 90，預設值為 80
    rsi_short_level = IntParameter(70, 90, default=80, space="buy", optimize=True)

    # 3. 🆕 新增：RSI 空單平倉的超賣門檻值：調整範圍 10 到 40，預設值為 20
    # 注意：出場參數的 space 要設定為 "sell"
    rsi_exit_level = IntParameter(10, 40, default=20, space="sell", optimize=True)

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        計算技術指標
        為了讓 Hyperopt 能優化指標週期，我們需要為可能的週期範圍預先計算，
        或者在 Freqtrade 規範內動態計算。這裡我們利用最佳實踐：預先產出調優範圍內的所有 RSI
        """
        # 由於 rsi_period 需要被優化，我們動態計算調優範圍內可能用到的所有 RSI 週期
        for val in self.rsi_period.range:
            dataframe[f"rsi_{val}"] = ta.RSI(dataframe, timeperiod=val)

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        定義進場訊號 (利用動態變數讀取 Hyperopt 測試中的參數)
        """
        # 初始化進場欄位
        dataframe["enter_long"] = 0
        dataframe["enter_short"] = 0
        dataframe["enter_tag"] = ""

        # 動態取得當前尋優循環中的參數值
        current_rsi_col = f"rsi_{self.rsi_period.value}"
        current_short_level = self.rsi_short_level.value

        # --- Short (做空) 進場邏輯 ---
        dataframe.loc[
            (dataframe[current_rsi_col] > current_short_level)
            & (dataframe["volume"] > 0),
            ["enter_short", "enter_tag"],
        ] = (1, f"rsi_over_{current_short_level}")

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        定義技術指標出場訊號 (主要靠 minimal_roi)
        """
        dataframe["exit_long"] = 0
        dataframe["exit_short"] = 0
        dataframe["exit_tag"] = ""

        # 動態取得當前尋優循環中的出場參數值
        current_rsi_col = f"rsi_{self.rsi_period.value}"
        current_exit_level = self.rsi_exit_level.value

        # --- Exit Short (空單平倉) 出場邏輯 ---
        # 條件：當前 K 線的 RSI 小於 20 (或當前尋優值) 
        dataframe.loc[
            (dataframe[current_rsi_col] < current_exit_level)
            & (dataframe["volume"] > 0),
            ["exit_short", "exit_tag"],
        ] = (1, f"rsi_under_{current_exit_level}")

        return dataframe

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: Optional[str],
                 side: str, **kwargs) -> float:
        """
        自訂槓桿乘數：全域強制設定為 15 倍槓桿
        """
        return self.leverage_value