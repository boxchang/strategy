import numpy as np
import pandas as pd
from pandas import DataFrame
from datetime import datetime
from typing import Optional
import talib.abstract as ta
import logging
from freqtrade.strategy import IStrategy, IntParameter

logger = logging.getLogger(__name__)

class SimpleRSIStrategy(IStrategy):
    INTERFACE_VERSION = 3
    timeframe = '15m'
    can_short = True
    stoploss = -0.10
    
    startup_candle_count = 25  # 增加預讀 K 線數量以滿足 EMA(25) 計算需求
    
    tradable_balance_ratio = 0.99
    trailing_stop = True
    trailing_stop_positive = 0.05
    trailing_stop_positive_offset = 0.08
    trailing_only_offset_is_reached = True

    buy_rsi = IntParameter(5, 50, default=20, space="buy", optimize=True)

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 計算 RSI
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=6)
        
        # 計算 EMA 指標
        dataframe['ema7'] = ta.EMA(dataframe, timeperiod=7)
        dataframe['ema25'] = ta.EMA(dataframe, timeperiod=25)
        
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['enter_long'] = 0
        dataframe['enter_short'] = 0
        
        # 定義進場條件: RSI < 20 且 EMA(7) < EMA(25)
        short_cond = (
            (dataframe['rsi'].notna()) & 
            (dataframe['rsi'] < 20) &
            (dataframe['ema7'] < dataframe['ema25'])
        )
        
        dataframe.loc[short_cond, 'enter_short'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['exit_long'] = 0
        dataframe['exit_short'] = 0
        
        return dataframe

    def custom_exit(self, pair: str, trade: 'Trade', current_time: datetime, current_rate: float,
                    current_profit: float, **kwargs) -> Optional[str]:
        # 當獲利達到 10% 時出場
        if current_profit >= 0.10:
            return 'profit_10_percent'
        return None

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: Optional[str],
                 side: str, **kwargs) -> float:
        return 10.0