import numpy as np
import pandas as pd
from pandas import DataFrame
from datetime import datetime
from typing import Optional
import talib.abstract as ta
import logging
from freqtrade.strategy import IStrategy, IntParameter, DecimalParameter
from freqtrade.persistence import Trade

logger = logging.getLogger(__name__)

class SimpleRSIStrategy(IStrategy):
    INTERFACE_VERSION = 3
    timeframe = '15m'
    can_short = False

    # 資金與加倉 (DCA) 控制：徹底關閉 DCA，避免單筆虧損無限放大
    position_adjustment_enable = False
    max_entry_position_adjustment = 0

    # 【動態獲利讓飛】放寬 ROI 限制，讓強彈趨勢充分發揮利潤
    minimal_roi = {
        "0": 0.12,     # 瞬時衝高 12% 出場
        "30": 0.06,    # 30 分鐘獲利 6% 出場
        "90": 0.03,    # 1.5 小時獲利 3% 出場
        "240": 0.015   # 4 小時獲利 1.5% 出場
    }

    # 參數化設定 (放寬 buy_rsi 彈性，並優化趨勢獲利)
    buy_rsi_range = IntParameter(5, 25, default=22, space="buy", optimize=True)
    buy_rsi_trend = IntParameter(28, 40, default=35, space="buy", optimize=True)
    exit_rsi = IntParameter(68, 88, default=75, space="sell", optimize=True)
    leverage_val = IntParameter(1, 3, default=2, space="entry", optimize=True)

    # 參數化 Trailing Stop：放寬移動止盈，拉大獲利幅度
    trailing_stop = True
    trailing_stop_positive = DecimalParameter(0.015, 0.06, default=0.02, space="sell", optimize=True)
    trailing_stop_positive_offset = DecimalParameter(0.03, 0.12, default=0.04, space="sell", optimize=True)
    trailing_only_offset_is_reached = True

    # 嚴格風控停損：固定單筆最大虧損為 4%（無 DCA 後，2倍槓桿下最大損耗僅 -8%）
    stoploss = -0.040
    use_custom_stoploss = False
    startup_candle_count = 200

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 1. RSI 指標
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=6)
        
        # 2. 長期與短期趨勢均線
        dataframe['ema_50'] = ta.EMA(dataframe, timeperiod=50)
        dataframe['ema_200'] = ta.EMA(dataframe, timeperiod=200)
        
        # 3. 趨勢強度指標 ADX
        dataframe['adx'] = ta.ADX(dataframe, timeperiod=14)

        # 4. 布林通道 (用於動態波段高點出場)
        bollinger = ta.BBANDS(dataframe, timeperiod=20, nbdevup=2.0, nbdevdn=2.0)
        dataframe['bb_upperband'] = bollinger['upperband']
        dataframe['bb_middleband'] = bollinger['middleband']

        # 5. 暴跌過濾：計算過去 1 小時 (4 根 15m K線) 的跌幅
        dataframe['roc_1h'] = ta.ROC(dataframe, timeperiod=4)

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['enter_long'] = 0

        # 通用防瀑布濾網：1小時內跌幅不大於 3.0%
        no_crash = (dataframe['roc_1h'] > -3.0)

        # 止跌反彈確認（關鍵！）：必須當前 K 線為陽線 (Close > Open) 且 RSI 開始向上彎曲
        is_reversal = (dataframe['close'] > dataframe['open']) & (dataframe['rsi'] > dataframe['rsi'].shift(1))

        # 模式 1：強多頭趨勢回檔 (Trend Pullback Engine)
        is_strong_uptrend = (dataframe['close'] > dataframe['ema_50']) & (dataframe['ema_50'] > dataframe['ema_200'])
        is_trending_market = (dataframe['adx'] >= 20)
        rsi_trend_dip = (dataframe['rsi'] < self.buy_rsi_trend.value)
        entry_mode_trend = is_strong_uptrend & is_trending_market & rsi_trend_dip & is_reversal & no_crash

        # 模式 2：盤整區間深跌抄底 (Range Scalp Engine)
        is_weak_uptrend = (dataframe['close'] > dataframe['ema_200'])
        is_ranging_market = (dataframe['adx'] < 20)
        rsi_range_dip = (dataframe['rsi'] < self.buy_rsi_range.value)
        entry_mode_range = is_weak_uptrend & is_ranging_market & rsi_range_dip & is_reversal & no_crash

        # 觸發任意一種進場模式
        dataframe.loc[
            entry_mode_trend | entry_mode_range,
            'enter_long'
        ] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['exit_long'] = 0
        return dataframe

    def custom_exit(self, pair: str, trade: Trade, current_time: datetime, current_rate: float,
                    current_profit: float, **kwargs) -> Optional[str]:

        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        if not dataframe.empty:
            last_candle = dataframe.iloc[-1]
            
            # 1. 布林通道上軌衝高爆發離場 (當價格觸碰布林上軌且獲利 > 2.0% 時平倉)
            if current_rate >= last_candle['bb_upperband'] and current_profit > 0.02:
                return "bb_upper_profit_exit"

            # 2. RSI 高位獲利平倉 (獲利 > 1.5% 且 RSI > 75)
            if last_candle['rsi'] > self.exit_rsi.value and current_profit > 0.015:
                return "rsi_profit_exit"

            # 3. 快速時間停損：持倉超過 3 小時 (180分) 且虧損 > 1.8%，代表動能不足，提早微虧認賠離場
            trade_duration = (current_time - trade.open_date_utc).total_seconds() / 60
            if trade_duration > 180 and current_profit < -0.018:
                return "early_stagnant_stop"

        return None

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: Optional[str],
                 side: str, **kwargs) -> float:
        return float(self.leverage_val.value)

    def adjust_trade_position(self, trade: Trade, current_time: datetime, current_rate: float,
                              current_profit: float, min_stake: float | None,
                              max_stake: float, **kwargs):
        # 徹底停用 DCA 加倉
        return None