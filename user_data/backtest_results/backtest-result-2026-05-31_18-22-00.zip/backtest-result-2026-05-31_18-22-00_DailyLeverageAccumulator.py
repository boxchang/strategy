import numpy as np
import pandas as pd
from pandas import DataFrame
from datetime import datetime, timezone
from typing import Optional, Union

from freqtrade.strategy import (
    IStrategy,
    DecimalParameter,
    IntParameter,
    BooleanParameter,
)
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib


class DailyLeverageAccumulator(IStrategy):
    """
    通用型 20x 槓桿量化精準建倉策略 (15m 強勢股高觸發版)
    
    此策略專為 20 倍槓桿合約定投建倉設計：
    - 固定每次進場保證金為 100.0 USDT (20x 槓桿下對應 2000 USDT 名義持倉)
    - 每日限制最多買入 3 次，累積打滿約 13,000 USDT 保證金 (約 260,000 USDT 總持倉)
    - 採用 15m 週期極簡 RSI(6) < 30 判斷，特別適合強勢單邊上漲股，在日內震盪回踩時精準撿入
    
    ====================================================================
    🛡️ 【20x 逐倉帳戶防強平與安全資金鏈實戰操作】 🛡️
    ====================================================================
    特別注意：由於本策略運行於「逐倉（Isolated Margin）模式」，每個倉位的風險完全隔離。
    帳戶內剩下未開倉的可用餘額（Free Balance）「預設不會」自動去支撐虧損的逐倉。
    
    為了防止 20x 槓桿因市場極端波動被斷頭，您必須實施以下防禦機制：
    
    1. 【手動防禦（推薦）】：
       密切監控持倉。當價格暴跌使現價逼近「強平價格」剩 1.5% 距離時，
       手動點擊交易所持倉旁的「增加保證金 (Add Margin)」，將合約帳戶中未開倉的可用餘額，
       手動注入逐倉中。此操作能瞬間將您的強平價向下壓低，重獲安全邊際。
       
    2. 【自動防禦（可選）】：
       在交易所（如幣安）逐倉介面中，開啟「自動追加保證金 (Auto-Deposit Margin)」功能。
       當倉位瀕臨強平時，系統會自動扣除您合約帳戶的可用餘額注入該倉位，以防爆倉。
       
    3. 【保本損防禦 (Break-even Stop Loss)】：
       建倉期結束後，只要價格脫離成本區，應立即將止損線上移至平均建倉成本，
       此時剩餘的可用餘額即可安全撤離。
    ====================================================================
    """

    INTERFACE_VERSION = 3

    # 交易設定：15m 週期，靈敏捕捉日內回踩低點
    timeframe = '15m'
    stoploss = -0.045  # 強制保證金硬止損 (約折合合約價格下跌 4.5% 時平倉，防止 5% 強平爆倉)

    # 禁用 Freqtrade 的自動 ROI 止盈，我們是長波段持倉，建倉期不做獲利了結
    minimal_roi = {
        "0": 10.0  # 設為 1000% 幾乎不觸發自動止盈
    }

    # 策略專屬自訂參數
    buy_rsi_trigger = IntParameter(25, 35, default=30, space="buy")  # 預設 RSI < 30 觸發
    max_buys_per_day = IntParameter(1, 5, default=3, space="buy")    # 已修改：每天最多允許機器人買入 3 次

    # 預算與持倉控制
    target_margin_usd = 100.0       # 已修改：固定每次進場使用 100.0 USDT 保證金
    max_total_trades = 130          # 已修改：限制最多累積加倉 130 次 (打滿約 13,000 USDT 保證金)

    # 用於在記憶體中追蹤每日交易次數
    custom_trade_tracker = {
        'current_day': '',
        'daily_buy_count': 0
    }

    # 繪圖設定
    plot_config = {
        'main_plot': {
            'ema25': {'color': '#FF69B4'},
        },
        'subplots': {
            "RSI": {
                'rsi6': {'color': '#FFA500'},
            }
        }
    }

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        計算技術指標：在 15m K 線基礎上計算指標
        """
        # 計算 6 週期的標準 Wilder's RSI (與 Binance App 一致，反應極為靈敏)
        dataframe['rsi6'] = ta.RSI(dataframe, timeperiod=6)
        
        # 僅保留一條均線作為主圖參考
        dataframe['ema25'] = ta.EMA(dataframe, timeperiod=25)
        
        # 用來偵測當前日期是否變更
        dataframe['date_string'] = pd.to_datetime(dataframe['date']).dt.strftime('%Y-%m-%d')

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        進場訊號：極簡判斷，只要 15m K棒的 RSI(6) 低於 30 即觸發買入
        """
        dataframe.loc[
            (
                (dataframe['rsi6'] < self.buy_rsi_trigger.value)
            ),
            'enter_long'
        ] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        建倉期不主動發出賣出訊號 (不進行獲利了結，由人工或大波段均線離場控制)
        """
        dataframe['exit_long'] = 0
        return dataframe

    def custom_stake_amount(self, pair: str, current_time: datetime, current_rate: float,
                            proposed_stake: float, min_stake: Optional[float], max_stake: float,
                            entry_tag: Optional[str], side: str, **kwargs) -> float:
        """
        精確倉位控制：每次下單保證金強制固定為 100.0 USDT
        """
        return self.target_margin_usd

    def confirm_trade_entry(self, pair: str, order_type: str, amount: float, rate: float,
                            time_in_force: str, current_time: datetime, entry_tag: Optional[str],
                            side: str, **kwargs) -> bool:
        """
        核心控制閘：確保每日僅交易限制次數，且不超額建倉
        """
        # 取得當前日期的字串格式 (YYYY-MM-DD)
        today_str = current_time.strftime('%Y-%m-%d')

        # 如果進入了新的一天，將每日買入計數器重置為 0
        if self.custom_trade_tracker['current_day'] != today_str:
            self.custom_trade_tracker['current_day'] = today_str
            self.custom_trade_tracker['daily_buy_count'] = 0

        # 【防護 1】限制當日買入次數最為 3 次
        if self.custom_trade_tracker['daily_buy_count'] >= self.max_buys_per_day.value:
            return False

        # 【防護 2】總建倉次數上限控制 (防止超過 13,000 保證金預算)
        # 取得目前已開倉的交易數量
        active_trades = len(self.get_open_trades())

        # 檢查是否超過總建倉次數上限
        if active_trades >= self.max_total_trades:
            return False

        # 通過驗證，將每日計數器加 1，允許下單
        self.custom_trade_tracker['daily_buy_count'] += 1
        return True