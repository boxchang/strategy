import numpy as np
import pandas as pd
from pandas import DataFrame
from datetime import datetime, time, timedelta
from typing import Optional
import talib.abstract as ta
import logging
from freqtrade.strategy import IStrategy, IntParameter

logger = logging.getLogger(__name__)

class SimpleRSIStrategy(IStrategy):
    INTERFACE_VERSION = 3
    timeframe = '15m'
    can_short = False # 改為僅做多
    
    stoploss = -0.04 
    use_custom_stoploss = False
    startup_candle_count = 20
    
    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # RSI指標
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=6)
        # 布林通道用於輔助過濾極端行情
        bollinger = ta.BBANDS(dataframe, timeperiod=20, nbdevup=2.0, nbdevdn=2.0)
        dataframe['bb_lower'] = bollinger['lowerband']
        return dataframe

    def is_allowed_time(self, current_time: datetime) -> bool:
        # 美股時間：09:30 - 16:00 ET (UTC-4/5)
        # 轉換為 UTC 時間：13:30 - 20:00 UTC
        # 前一小時 (08:30-09:30 ET) = 12:30-13:30 UTC
        # 後一小時 (16:00-17:00 ET) = 20:00-21:00 UTC
        
        # 定義允許交易的 UTC 時間區間
        # 這裡簡化為 12:30-13:30 UTC 以及 20:00-21:00 UTC
        utc_time = current_time.time()
        
        pre_market = time(12, 30) <= utc_time < time(13, 30)
        post_market = time(20, 0) <= utc_time < time(21, 0)
        
        return pre_market or post_market

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['enter_long'] = 0
        
        # RSI < 20 進場，並加入時間檢查
        rsi_low = (dataframe['rsi'] < 20)
        
        # 應用時間濾網
        is_trading_time = dataframe['date'].apply(self.is_allowed_time)
        
        long_cond = rsi_low & is_trading_time
        
        dataframe.loc[long_cond, 'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 出場條件：RSI 回升至 50
        exit_long_cond = (dataframe['rsi'] > 50)
        dataframe.loc[exit_long_cond, 'exit_long'] = 1
        return dataframe

    def custom_exit(self, pair: str, trade: 'Trade', current_time: datetime, current_rate: float,
                    current_profit: float, **kwargs) -> Optional[str]:
        if current_profit >= 0.08:
            return 'profit_8_percent'
        return None

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: Optional[str],
                 side: str, **kwargs) -> float:
        return 5.0