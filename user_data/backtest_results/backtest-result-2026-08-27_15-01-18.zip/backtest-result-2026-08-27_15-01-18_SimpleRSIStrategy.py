import numpy as np
import pandas as pd
from pandas import DataFrame
from datetime import datetime
from typing import Optional
import talib.abstract as ta
import logging
from freqtrade.strategy import IStrategy, IntParameter, DecimalParameter
from freqtrade.persistence import Trade

logger = logging.getLogger(__name__)

class SimpleRSIStrategy(IStrategy):
    INTERFACE_VERSION = 3
    timeframe = '15m'
    can_short = False

    # 資金與加倉 (DCA) 控制
    position_adjustment_enable = True
    max_entry_position_adjustment = 1

    # 【動態獲利讓飛】放寬 ROI 限制，讓強彈趨勢充分發揮利潤
    minimal_roi = {
        "0": 0.15,     # 瞬時衝高 15% 出場
        "40": 0.08,    # 40 分鐘獲利 8% 出場
        "120": 0.04,   # 2 小時獲利 4% 出場
        "360": 0.02    # 6 小時獲利 2% 保本
    }

    # 參數化設定 (放寬 buy_rsi 彈性，並優化趨勢獲利)
    buy_rsi_range = IntParameter(5, 25, default=22, space="buy", optimize=True)
    buy_rsi_trend = IntParameter(28, 40, default=35, space="buy", optimize=True)
    exit_rsi = IntParameter(68, 88, default=75, space="sell", optimize=True)
    leverage_val = IntParameter(1, 3, default=2, space="entry", optimize=True)

    # 參數化 Trailing Stop：放寬移動止盈，拉大獲利幅度
    trailing_stop = True
    trailing_stop_positive = DecimalParameter(0.015, 0.06, default=0.025, space="sell", optimize=True)
    trailing_stop_positive_offset = DecimalParameter(0.03, 0.12, default=0.05, space="sell", optimize=True)
    trailing_only_offset_is_reached = True

    # 嚴格風控停損
    stoploss = -0.055
    use_custom_stoploss = False
    startup_candle_count = 200

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 1. RSI 指標
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=6)
        
        # 2. 長期與短期趨勢均線
        dataframe['ema_50'] = ta.EMA(dataframe, timeperiod=50)
        dataframe['ema_200'] = ta.EMA(dataframe, timeperiod=200)
        
        # 3. 趨勢強度指標 ADX
        dataframe['adx'] = ta.ADX(dataframe, timeperiod=14)

        # 4. 布林通道 (用於動態波段高點出場)
        bollinger = ta.BBANDS(dataframe, timeperiod=20, nbdevup=2.0, nbdevdn=2.0)
        dataframe['bb_upperband'] = bollinger['upperband']
        dataframe['bb_middleband'] = bollinger['middleband']

        # 5. 暴跌過濾：計算過去 1 小時 (4 根 15m K線) 的跌幅
        dataframe['roc_1h'] = ta.ROC(dataframe, timeperiod=4)

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['enter_long'] = 0

        # 通用防瀑布濾網：1小時內跌幅不大於 3.5%
        no_crash = (dataframe['roc_1h'] > -3.5)

        # 模式 1：強多頭趨勢回檔 (Trend Pullback Engine) - 貢獻大部分高利潤單！
        # 條件：價格 > EMA50 > EMA200 且 ADX > 20 代表強趨勢，RSI 只要 < 35 即可買進
        is_strong_uptrend = (dataframe['close'] > dataframe['ema_50']) & (dataframe['ema_50'] > dataframe['ema_200'])
        is_trending_market = (dataframe['adx'] >= 20)
        rsi_trend_dip = (dataframe['rsi'] < self.buy_rsi_trend.value)
        entry_mode_trend = is_strong_uptrend & is_trending_market & rsi_trend_dip & no_crash

        # 模式 2：盤整區間深跌抄底 (Range Scalp Engine)
        # 條件：價格 > EMA200 且 ADX < 20 震盪盤，要求深跌 RSI < 22 抄底
        is_weak_uptrend = (dataframe['close'] > dataframe['ema_200'])
        is_ranging_market = (dataframe['adx'] < 20)
        rsi_range_dip = (dataframe['rsi'] < self.buy_rsi_range.value)
        entry_mode_range = is_weak_uptrend & is_ranging_market & rsi_range_dip & no_crash

        # 觸發任意一種進場模式
        dataframe.loc[
            entry_mode_trend | entry_mode_range,
            'enter_long'
        ] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['exit_long'] = 0
        return dataframe

    def custom_exit(self, pair: str, trade: Trade, current_time: datetime, current_rate: float,
                    current_profit: float, **kwargs) -> Optional[str]:
        
        # 1. DCA 保本解套機制
        if trade.nr_of_successful_entries > 1 and current_profit >= 0.008:
            return "dca_break_even_exit"

        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        if not dataframe.empty:
            last_candle = dataframe.iloc[-1]
            
            # 2. 布林通道上軌衝高爆發離場 (當價格觸碰布林上軌且獲利 > 2.5% 時平倉，吃滿大陽線)
            if current_rate >= last_candle['bb_upperband'] and current_profit > 0.025:
                return "bb_upper_profit_exit"

            # 3. RSI 高位獲利平倉 (獲利 > 2.0% 且 RSI > 75)
            if last_candle['rsi'] > self.exit_rsi.value and current_profit > 0.02:
                return "rsi_profit_exit"

            # 4. 智慧趨勢時間停損：持倉超過 12 小時 (720分)，且「價格跌破 EMA200」與虧損 > 3.5% 才砍單
            #    避免把正常波段震盪的單子砍在阿呆谷
            trade_duration = (current_time - trade.open_date_utc).total_seconds() / 60
            if trade_duration > 720 and current_profit < -0.035:
                if last_candle['close'] < last_candle['ema_200']:
                    return "time_trend_break_stop"

        return None

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: Optional[str],
                 side: str, **kwargs) -> float:
        return float(self.leverage_val.value)

    def adjust_trade_position(self, trade: Trade, current_time: datetime, current_rate: float,
                              current_profit: float, min_stake: float | None,
                              max_stake: float, **kwargs):
        if trade.nr_of_successful_entries >= self.max_entry_position_adjustment:
            return None

        if trade.date_last_filled_utc:
            seconds = (current_time - trade.date_last_filled_utc).total_seconds()
            if seconds < 300:
                return None

        dataframe, _ = self.dp.get_analyzed_dataframe(trade.pair, self.timeframe)
        if dataframe.empty:
            return None
        last_rsi = dataframe.iloc[-1]['rsi']

        base_stake = self.config.get('stake_amount', 30)
        if isinstance(base_stake, str) or base_stake is None:
            base_stake = 30

        min_s = min_stake if min_stake is not None else 0.0

        # 當浮虧達到 -3.5% 且 RSI 低於 20 時加碼原本金額的 60%
        if current_profit <= -0.035 and last_rsi < 20 and trade.nr_of_successful_entries == 1:
            return max(min_s, min(base_stake * 0.6, max_stake)), "dca_stage1"

        return None