import numpy as np
import pandas as pd
from pandas import DataFrame
import pandas_ta as pta
from freqtrade.strategy import IStrategy


class HighRsiShortDcaStrategy(IStrategy):
    """
    4h Short-Only Strategy
    - RSI > 90 Enter Short
    - RSI < 25 Exit Short
    - Price > 100 to trigger entry
    - Pairs: BZUSDT, CLUSDT
    - Leverage: 10x
    - Stoploss: Disabled (Set to 100%)
    - DCA: Double position size every -100% ROI, Max 3 safety orders
    """

    # 策略基本設定
    timeframe = '4h'
    can_short = True
    
    # 不使用固定止損（設定為 -100% 表示不設防護性止損）
    stoploss = -1.0
    
    # 關閉標準倍數加倉，改由 adjust_trade_position 完全控制
    position_adjustment_enable = True
    max_entry_position_adjustment = 3  # 最多補倉 3 次

    # 交易對白名單設定
    pair_whitelist = [
        "BZ/USDT:USDT",
        "CL/USDT:USDT"
    ]

    def leverage(self, pair: str, current_time: str, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: str,
                 side: str, **kwargs) -> float:
        """設定固定 10 倍槓桿"""
        return 10.0

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """計算 RSI 指標"""
        dataframe['rsi'] = pta.rsi(dataframe['close'], length=14)
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """進場條件：價格 > 100 且 RSI > 90 時做空"""
        dataframe.loc[
            (
                (dataframe['close'] > 100) &
                (dataframe['rsi'] > 90) &
                (dataframe['volume'] > 0)
            ),
            'enter_short'] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """出場條件：RSI < 25 時平倉出局"""
        dataframe.loc[
            (
                (dataframe['rsi'] < 25) &
                (dataframe['volume'] > 0)
            ),
            'exit_short'] = 1

        return dataframe

    def adjust_trade_position(self, trade, current_time, current_rate: float,
                              current_profit: float, min_stake: float,
                              max_stake: float, current_entry_level: int, **kwargs):
        """
        補倉邏輯：
        - 每當虧損達到 100% (current_profit <= -1.0)
        - 補倉數量為目前持倉數量的 2 倍
        - 最多補倉 3 次 (current_entry_level < 3)
        """
        # 僅在有虧損時進行檢查
        if current_profit > -1.0:
            return None

        # 限制補倉次數最多為 3 次 (初始進場為 level 0, 補倉分別為 level 1, 2, 3)
        if current_entry_level >= self.max_entry_position_adjustment:
            return None

        # 計算欲加倉的金額：當前持倉總數量的 2 倍金額
        # trade.amount 為當前累積持倉數量
        desired_stake_amount = (trade.amount * 2) * current_rate

        # 確保加倉金額小於帳戶允許的最大下單金額
        if desired_stake_amount > max_stake:
            desired_stake_amount = max_stake

        # 確保不低於交易所最小下單門檻
        if desired_stake_amount < min_stake:
            return None

        return desired_stake_amount