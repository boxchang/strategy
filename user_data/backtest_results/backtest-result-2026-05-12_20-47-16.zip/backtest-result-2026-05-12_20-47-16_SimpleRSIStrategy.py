from freqtrade.strategy.interface import IStrategy
from pandas import DataFrame
import talib.abstract as ta
from datetime import datetime
from typing import Optional

class SimpleRSIStrategy(IStrategy):
    position_adjustment_enable = False
    timeframe = '15m'
    leverage_value = 1.0

    minimal_roi = {
        "0": 0.03,
        "30": 0.02,
        "60": 0.01
    }

    stoploss = -0.02

    trailing_stop = True
    trailing_stop_positive = 0.01
    trailing_stop_positive_offset = 0.02
    trailing_only_offset_is_reached = True

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # RSI 指標
        dataframe['rsi'] = ta.RSI(dataframe['close'], timeperiod=14)

        # 成交量均線 (用來判斷大戶進場)
        dataframe['vol_ma20'] = ta.SMA(dataframe['volume'], timeperiod=20)

        # 均線 (MA5 與 MA20)
        dataframe['ma5'] = ta.SMA(dataframe['close'], timeperiod=5)
        dataframe['ma20'] = ta.SMA(dataframe['close'], timeperiod=20)

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 進場條件：RSI < 20 + 當前成交量 > 20期均量 + MA5 > MA20
        dataframe.loc[
            (dataframe['rsi'] < 40) &
            (dataframe['volume'] > dataframe['vol_ma20']) &
            (dataframe['ma5'] > dataframe['ma20']),
            'enter_long'
        ] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 出場條件：MA5 < MA20
        dataframe.loc[
            (dataframe['rsi'] > 80),
            'exit_long'
        ] = 1

        return dataframe

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: Optional[str],
                 side: str, **kwargs) -> float:
        # 回傳槓桿倍數
        return self.leverage_value