import logging
import numpy as np
import pandas as pd
from pandas import DataFrame
import pandas_ta as pta
from freqtrade.strategy import IStrategy, IntParameter

# 建立 Logger 物件以在控制台印出 Log
logger = logging.getLogger(__name__)

class HighRsiShortDcaStrategy(IStrategy):
    """
    4h Short-Only Strategy with Hyperoptable RSI Parameters
    - RSI Entry > rsi_buy_level (可優化範圍 70-95)
    - RSI Exit < rsi_sell_level (可優化範圍 10-40)
    - RSI Period = rsi_period (可優化範圍 7-21)
    """

    # 策略基本設定
    timeframe = '4h'
    can_short = True
    
    stoploss = -1.0

    minimal_roi = {
        "0": 0.10
    }
    
    position_adjustment_enable = True
    max_entry_position_adjustment = 3

    # ==================== 可優化參數定義 ====================
    # RSI 週期，預設 14，範圍 7 到 21
    rsi_period = IntParameter(7, 21, default=14, space='buy', optimize=True)
    
    # 做空進場觸發點（RSI 高於此值進場），預設 90，範圍 70 到 95
    rsi_short_entry = IntParameter(70, 95, default=90, space='buy', optimize=True)
    
    # 做空平倉出場點（RSI 低於此值出場），預設 25，範圍 10 到 40
    rsi_short_exit = IntParameter(10, 40, default=25, space='sell', optimize=True)
    # ========================================================

    def leverage(self, pair: str, current_time: str, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: str,
                 side: str, **kwargs) -> float:
        return 10.0

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """計算不同週期的 RSI 指標"""
        # 如果開啟 Hyperopt 尋找最佳週期，會依據當前的 rsi_period 動態計算
        dataframe['rsi'] = pta.rsi(dataframe['close'], length=self.rsi_period.value)
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """進場條件：價格 > 100 且 RSI > rsi_short_entry 時做空"""
        dataframe.loc[
            (
                (dataframe['close'] > 95) &
                (dataframe['rsi'] > self.rsi_short_entry.value) &
                (dataframe['volume'] > 0)
            ),
            'enter_short'] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """出場條件：RSI < rsi_short_exit 時平倉出局"""
        dataframe.loc[
            (
                (dataframe['rsi'] < self.rsi_short_exit.value) &
                (dataframe['volume'] > 0)
            ),
            'exit_short'] = 1

        return dataframe

    def adjust_trade_position(self, trade, current_time, current_rate: float,
                              current_profit: float, min_stake: float,
                              max_stake: float, **kwargs):
        """
        修正後的 DCA 補倉邏輯：
        基於價格相對於「上一次進場價」的變動幅度，確保精準補滿 3 次。
        """
        # 取得已發生的加倉次數 (初始進場算 0)
        current_entry_count = trade.nr_of_successful_entries - 1

        # 限制最多補倉 3 次
        if current_entry_count >= self.max_entry_position_adjustment:
            return None

        # 取得上一次買入/加倉的成交價格 (Last Order Price)
        last_order = trade.select_filled_orders('enter_short')[-1]
        last_price = last_order.price

        # 做空 (Short)：價格需要比「上一次成交價」更高，才算虧損
        # 在 10x 槓桿下，價格比上次進場價上漲 10%，代表該階保證金虧損 100%
        price_drop_or_gain = (current_rate - last_price) / last_price

        # 如果上漲幅度未達到 10% (0.10)，則不觸發補倉
        if price_drop_or_gain < 0.10:
            return None

        # 取得第一筆初始進場的保證金金額
        initial_stake = trade.select_filled_orders('enter_short')[0].cost

        # 每次補倉金額 = 初始保證金的 2 倍 (固定補 2x)
        desired_stake_amount = initial_stake * 2

        # 資金門檻保護
        if max_stake is not None and desired_stake_amount > max_stake:
            desired_stake_amount = max_stake

        if min_stake is not None and desired_stake_amount < min_stake:
            return None

        logger.info(
            f"[DCA 觸發第 {current_entry_count + 1} 次補倉] "
            f"上次價格: {last_price:.4f}, 當前價格: {current_rate:.4f} (上漲 {price_drop_or_gain:.2%})"
        )

        return desired_stake_amount