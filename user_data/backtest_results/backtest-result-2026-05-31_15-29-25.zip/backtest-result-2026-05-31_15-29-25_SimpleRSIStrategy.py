import numpy as np
import pandas as pd
from pandas import DataFrame
from datetime import datetime, timezone
from typing import Optional, Union
import logging

from freqtrade.strategy import (
    IStrategy,
    DecimalParameter,
    IntParameter,
    BooleanParameter,
)
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib


class SimpleRSIStrategy(IStrategy):
    """
    RSI 雙向極速交易策略 (15x 槓桿 + 三階層虧損加倉防禦版)
    
    此策略專為 15m 週期的高波動標的設計，支持「雙向交易 (Long/Short)」與「金字塔式虧損加倉 (DCA)」：
    本版本已全面參數化，支持使用 Freqtrade Hyperopt 自動優化買賣與 DCA 門檻。
    """

    # 啟用日誌記錄器
    logger = logging.getLogger(__name__)

    # Freqtrade 策略介面版本
    INTERFACE_VERSION = 3

    # 1. 核心交易設定
    timeframe = '15m'      # 運行 K 線週期：15 分鐘 (適合敏捷雙向交易)
    can_short = True       # 啟用做空功能 (支持 Long / Short 雙向套利)
    
    # 2. 資金與加倉 (DCA) 控制
    position_adjustment_enable = True       # 必須設為 True 才能啟用自訂的加倉機制
    max_entry_position_adjustment = 10      # 單筆交易最大允許的追加進場次數 (配合第3階最大11次交易)

    # 3. 止盈止損設定
    stoploss = -0.90

    # 4. 移動止損 (Trailing Stop) - 用於在大趨勢噴發時抱緊利潤
    trailing_stop = True
    trailing_stop_positive = 0.05      # 獲利達到 5% 後啟動移動止損
    trailing_stop_positive_offset = 0.08  # 觸發移動止損的利潤偏移量 (8%)
    trailing_only_offset_is_reached = True # 只有在達到 offset 後才開始移動

    # 5. 階層止盈 (ROI) 表 - 隨著持有時間增加，逐步降低止盈期望值
    minimal_roi = {
        "0": 0.20,     # 開倉即刻止盈目標：+20% (標的上漲約 1.33%)
        "30": 0.15,    # 持倉 30 分鐘後止盈目標：+15%
        "60": 0.10     # 持倉 60 分鐘後止盈目標：+10%
    }

    # 6. 槓桿倍數設定
    leverage_value = 15.0

    # =====================================================================
    # 🎯 【HYPEROPT 超參數優化定義空間】
    # =====================================================================
    # 買入與賣出 RSI 臨界點
    buy_rsi = IntParameter(20, 40, default=30, space="buy", optimize=True)
    sell_rsi = IntParameter(60, 90, default=80, space="sell", optimize=True)

    # 三階段 DCA 的虧損加倉觸發比例 (合約帳戶浮動利潤虧損比例)
    dca_stage1_profit = DecimalParameter(-0.55, -0.35, default=-0.45, decimals=2, space="buy", optimize=True)
    dca_stage2_profit = DecimalParameter(-0.68, -0.50, default=-0.60, decimals=2, space="buy", optimize=True)
    dca_stage3_profit = DecimalParameter(-0.85, -0.65, default=-0.70, decimals=2, space="buy", optimize=True)
    # =====================================================================

    # 繪圖設定
    plot_config = {
        'main_plot': {},
        'subplots': {
            "RSI": {
                'rsi': {'color': '#FFA500'},
            }
        }
    }

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        計算技術指標
        """
        # 採用 Freqtrade 標準 abstract 安全寫法，防止與 pandas 索引混淆
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        進場信號：
        - 多頭 (Long)：RSI < buy_rsi (超賣區低吸)
        - 空頭 (Short)：RSI > sell_rsi (超買區高拋)
        """
        # 初始化信號欄位
        dataframe['enter_long'] = 0
        dataframe['enter_short'] = 0
        dataframe['enter_tag'] = ''

        # 做多信號 (使用優化參數 buy_rsi)
        dataframe.loc[
            (dataframe['rsi'] < self.buy_rsi.value),
            ['enter_long', 'enter_tag']
        ] = (1, 'rsi_long')

        # 做空信號 (使用優化參數 sell_rsi)
        dataframe.loc[
            (dataframe['rsi'] > self.sell_rsi.value),
            ['enter_short', 'enter_tag']
        ] = (1, 'rsi_short')

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        出場信號：
        - 多頭平倉 (Exit Long)：RSI 突破 sell_rsi
        - 空頭平倉 (Exit Short)：RSI 跌破 buy_rsi
        """
        # 初始化出場欄位
        dataframe['exit_long'] = 0
        dataframe['exit_short'] = 0
        dataframe['exit_tag'] = ''

        # 多單平倉 (使用優化參數 sell_rsi)
        dataframe.loc[
            (dataframe['rsi'] > self.sell_rsi.value),
            ['exit_long', 'exit_tag']
        ] = (1, 'rsi_exit_long')

        # 空單平倉 (使用優化參數 buy_rsi)
        dataframe.loc[
            (dataframe['rsi'] < self.buy_rsi.value),
            ['exit_short', 'exit_tag']
        ] = (1, 'rsi_exit_short')

        return dataframe

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: Optional[str],
                 side: str, **kwargs) -> float:
        """
        自訂槓桿乘數：全域強制設定為 15 倍槓桿
        """
        return self.leverage_value

    def adjust_trade_position(
            self,
            trade,
            current_time: datetime,
            current_rate: float,
            current_profit: float,
            min_stake: float | None,
            max_stake: float,
            current_entry_rate: float,
            current_exit_rate: float,
            current_entry_profit: float,
            current_exit_profit: float,
            **kwargs
    ):
        """
        動態防禦補倉機制 (DCA)：
        
        當前交易產生虧損時，透過 3 階段加倉拉低均價，提高解套與反彈獲利的機率。
        """
        # 1. 檢查冷卻時間：避免在極短時間內（如同一根 K 線內）連續重疊加倉
        if trade.date_last_filled_utc:
            seconds = (current_time - trade.date_last_filled_utc).total_seconds()

            # 距離上一次補倉成交不滿 5 分鐘，拒絕加倉
            if seconds < 5 * 60:
                return None

        # 2. 輸出詳細偵錯日誌
        self.logger.info(
            f"DCA 檢測呼叫: {trade.pair}, 當前持倉利潤={current_profit:.4f}, "
            f"目前成交次數(DCA次數)={trade.nr_of_successful_entries}"
        )

        # 3. 三階層虧損加倉邏輯 (已全面改用自訂優化參數 .value 讀取)：
        # 【第一階】：當前合約利潤 <= dca_stage1_profit 且 總成交次數 < 4
        if current_profit <= self.dca_stage1_profit.value and trade.nr_of_successful_entries < 4:
            stake = min(100, max_stake)
            return stake, "test_dca_stage1"
            
        # 【第二階】：當前合約利潤 <= dca_stage2_profit 且 總成交次數 < 7
        elif current_profit <= self.dca_stage2_profit.value and trade.nr_of_successful_entries < 7:
            stake = min(150, max_stake)
            return stake, "test_dca_stage2"
            
        # 【第三階】：當前合約利潤 <= dca_stage3_profit 且 總成交次數 < 11
        elif current_profit <= self.dca_stage3_profit.value and trade.nr_of_successful_entries < 11:
            stake = min(200, max_stake)
            return stake, "test_dca_stage3"

        # 若未達到補倉標準，返回 None
        return None