# pragma pylint: disable=missing-docstring, invalid-name, pointless-string-statement
# isort: skip_file
import numpy as np
import pandas as pd
from datetime import datetime
from typing import Optional
from freqtrade.strategy import IStrategy, IntParameter
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib

class LucyStrategy(IStrategy):
    """
    LucyStrategy:
    - 在美國週休不開盤的時候 (星期六、星期日)，RSI < 30 時做多 (買進)。
    - 在美國週休不開盤的時候 (星期六、星期日)，RSI > 80 時做空 (Short)。
    - 任何時候 RSI > 80 時平倉做多 (賣出)。
    - 任何時候 RSI < 30 時平倉做空 (買回)。
    """
    
    # 策略介面版本
    INTERFACE_VERSION = 3

    # 允許做空 (請確保您的交易所和 config.json 支援 Futures/Margin)
    can_short = True

    # 預設的 Minimal ROI (投資回報率) 與 Stoploss (止損)
    # 這裡將其設定得很寬鬆，主要依賴 RSI 訊號來平倉
    minimal_roi = {
        "0": 100.0  # 禁用 ROI 平倉
    }
    stoploss = -0.99  # 寬鬆止損

    # 預設 K 線週期 (Timeframe)，更改為 15m
    timeframe = '15m'

    # --- Hyperopt 參數設定 ---
    # 槓桿參數 (預設 20，範圍 1~50)
    leverage_param = IntParameter(1, 50, default=20, space='buy', optimize=True)
    
    # RSI 進場參數
    rsi_entry_long = IntParameter(10, 45, default=30, space='buy', optimize=True)
    rsi_entry_short = IntParameter(55, 95, default=80, space='buy', optimize=True)
    
    # RSI 出場參數
    rsi_exit_long = IntParameter(55, 95, default=80, space='sell', optimize=True)
    rsi_exit_short = IntParameter(10, 45, default=30, space='sell', optimize=True)

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: Optional[str],
                 side: str, **kwargs) -> float:
        """
        設定策略槓桿倍數
        使用 leverage_param 參數，支援 Hyperopt 尋找最佳槓桿
        """
        return float(self.leverage_param.value)

    def populate_indicators(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        """
        計算技術指標
        """
        # 計算 RSI，預設週期為 14
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        
        # 取得星期幾 (0 是星期一，5 是星期六，6 是星期日)
        # Freqtrade 的時間預設為 UTC。星期六和星期日(UTC)完美落在美國傳統市場(美股)的週末休市期間。
        dataframe['dayofweek'] = dataframe['date'].dt.dayofweek
        
        return dataframe

    def populate_entry_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        """
        設定進場條件 (做多 / 做空)
        """
        # 做多條件：週末 (星期六、星期日) 且 RSI 小於最佳化參數
        long_condition = (
            (dataframe['dayofweek'].isin([5, 6])) & 
            (dataframe['rsi'] < self.rsi_entry_long.value)
        )
        dataframe.loc[long_condition, 'enter_long'] = 1

        # 做空條件：週末 (星期六、星期日) 且 RSI 大於最佳化參數
        short_condition = (
            (dataframe['dayofweek'].isin([5, 6])) & 
            (dataframe['rsi'] > self.rsi_entry_short.value)
        )
        dataframe.loc[short_condition, 'enter_short'] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        """
        設定出場條件 (平多 / 平空)
        """
        # 平多條件 (賣出)：RSI 大於最佳化參數
        exit_long_condition = (
            (dataframe['rsi'] > self.rsi_exit_long.value)
        )
        dataframe.loc[exit_long_condition, 'exit_long'] = 1

        # 平空條件 (買回)：RSI 小於最佳化參數
        exit_short_condition = (
            (dataframe['rsi'] < self.rsi_exit_short.value)
        )
        dataframe.loc[exit_short_condition, 'exit_short'] = 1

        return dataframe